﻿#include "stdafx.h"
#include "resource.h"
#include "DiffCompareFrame.h"
#include "DataLoader.h"
#include <vector>
#include <algorithm>
#include "CommonUtils.h"
using namespace CommonUtil;
using namespace RouteInfo;
#define WM_LOGIC_DIFF_FINISHED (WM_USER + 101)
#define WM_RENDER_NEXT_CHUNK (WM_USER +102)
// ==========================================
// 공통 구조체 및 열거형 정의
// ==========================================
		// 4. 메인 UI로 전달할 패키지 구조체 생성
struct ResultPackage {
	std::vector<CString> left;
	std::vector<CString> right;
	std::vector<DiffLine> diffs;
};

// 2. 텍스트를 분석하여 키와 순서 번호를 부여하는 함수
//static std::vector<LineToken> GetLineTokens(const std::vector<CString>& lines)
//{
//	std::vector<LineToken> tokens;
//	std::map<CString, int> keyCounts; // 키별 등장 횟수 카운트 맵
//
//	for (const auto& line : lines)
//	{
//		LineToken tok;
//		tok.fullLine = line;
//
//		int nEqual = line.Find(_T('='));
//		if (nEqual != -1)
//		{
//			tok.key = line.Left(nEqual);
//			tok.key.Trim();
//		}
//		else
//		{
//			tok.key = line;
//			tok.key.Trim();
//		}
//
//		// 동일한 키가 몇 번째 나왔는지 기록 후 카운트 증가
//		tok.occurrence = keyCounts[tok.key]++;
//		tokens.push_back(tok);
//	}
//	return tokens;
//}
struct BinBlockUnit {
	CString key;                  // 최상위 블록의 고유 이름 (예: "[폐색 이름] 2A", "[ Station Information ]")
	std::vector<CString> lines;   // 해당 블록에 속한 모든 하위 라인들
};

// ★ 하위 섹션 대괄호(`[`)에 흔들리지 않고, 최상위 구분선(`========`) 기준으로만 블록을 쪼개는 파서
std::vector<BinBlockUnit> ParseIntoBinBlocks(const std::vector<CString>& srcLines)
{
	std::vector<BinBlockUnit> blocks;
	BinBlockUnit currentBlock;
	bool inBlock = false;

	for (const auto& line : srcLines)
	{
		// 최상위 구분선(대략 8개 이상의 '='로 시작하는 라인)을 만났을 때만 새로운 블록의 시작으로 인정
		bool isMajorSeparator = (line.GetLength() >= 8 && line.Left(8) == _T("========"));

		if (isMajorSeparator)
		{
			// 이전 블록이 있으면 저장
			if (inBlock && !currentBlock.lines.empty())
			{
				blocks.push_back(currentBlock);
				currentBlock = BinBlockUnit();
			}
			inBlock = true;
			currentBlock.lines.push_back(line);
		}
		else if (inBlock)
		{
			// 구분선 바로 다음 줄에 나오는 메인 이름(예: "[폐색 이름] 2A", "[ Station Information ]")을 블록의 고유 키로 지정
			if (currentBlock.key.IsEmpty() && line.GetLength() > 0)
			{
				currentBlock.key = line;
			}
			currentBlock.lines.push_back(line);
		}
		else
		{
			// 맨 상단 헤더 영역
			BinBlockUnit headerBlock;
			headerBlock.key = line;
			headerBlock.lines.push_back(line);
			blocks.push_back(headerBlock);
		}
	}

	if (inBlock && !currentBlock.lines.empty())
	{
		blocks.push_back(currentBlock);
	}

	return blocks;
}

// ★ 블록(Key) 단위 LCS를 수행하는 안전한 바이너리 비교 함수
static std::vector<DiffLine> ComputeBinDiff(
	const std::vector<CString>& leftLines,
	const std::vector<CString>& rightLines)
{
	std::vector<BinBlockUnit> leftBlocks = ParseIntoBinBlocks(leftLines);
	std::vector<BinBlockUnit> rightBlocks = ParseIntoBinBlocks(rightLines);

	const int m = static_cast<int>(leftBlocks.size());
	const int n = static_cast<int>(rightBlocks.size());

	// 1. 블록 키(Key)를 기준으로 LCS DP 테이블 생성
	std::vector<std::vector<int>> dp(m + 1, std::vector<int>(n + 1, 0));
	for (int i = 1; i <= m; ++i)
	{
		for (int j = 1; j <= n; ++j)
		{
			if (leftBlocks[i - 1].key == rightBlocks[j - 1].key)
			{
				dp[i][j] = dp[i - 1][j - 1] + 1;
			}
			else
			{
				dp[i][j] = (std::max)(dp[i - 1][j], dp[i][j - 1]);
			}
		}
	}

	// 2. 블록 단위 백트래킹 (LCS 오퍼레이션 수집)
	enum BlockOpType {
		OP_MATCH, OP_DELETE, OP_INSERT
	};
	struct BlockOperation {
		BlockOpType type;
		int lIdx;
		int rIdx;
	};

	std::vector<BlockOperation> blockOps;
	int i = m, j = n;
	while (i > 0 || j > 0)
	{
		if (i > 0 && j > 0 && leftBlocks[i - 1].key == rightBlocks[j - 1].key)
		{
			blockOps.push_back({ OP_MATCH, i - 1, j - 1 });
			--i; --j;
		}
		else if (j > 0 && (i == 0 || dp[i][j - 1] >= dp[i - 1][j]))
		{
			blockOps.push_back({ OP_INSERT, -1, j - 1 });
			--j;
		}
		else if (i > 0)
		{
			blockOps.push_back({ OP_DELETE, i - 1, -1 });
			--i;
		}
	}
	std::reverse(blockOps.begin(), blockOps.end());

	// 3. 최종 DiffLine 결과 조립
	std::vector<DiffLine> result;

	for (const auto& op : blockOps)
	{
		if (op.type == OP_MATCH)
		{
			// 키가 같은 블록 내부의 라인들 비교
			const auto& lBlk = leftBlocks[op.lIdx].lines;
			const auto& rBlk = rightBlocks[op.rIdx].lines;
			size_t maxLine = (std::max)(lBlk.size(), rBlk.size());

			for (size_t k = 0; k < maxLine; ++k)
			{
				bool bLHas = (k < lBlk.size());
				bool bRHas = (k < rBlk.size());

				if (bLHas && bRHas)
				{
					if (lBlk[k] == rBlk[k])
						result.push_back({ DIFF_MATCH, lBlk[k], rBlk[k] });
					else
						result.push_back({ DIFF_CHANGE, lBlk[k], rBlk[k] });
				}
				else if (bLHas)
				{
					result.push_back({ DIFF_DELETE, lBlk[k], CString() });
				}
				else
				{
					result.push_back({ DIFF_INSERT, CString(), rBlk[k] });
				}
			}
		}
		else if (op.type == OP_DELETE)
		{
			// 좌측에만 통째로 있는 블록 -> 전부 삭제 처리 (우측은 빈 줄 삽입)
			for (const auto& line : leftBlocks[op.lIdx].lines)
			{
				result.push_back({ DIFF_DELETE, line, CString() });
			}
		}
		else if (op.type == OP_INSERT)
		{
			// 우측에만 통째로 있는 블록 -> 전부 추가 처리 (좌측은 빈 줄 삽입)
			for (const auto& line : rightBlocks[op.rIdx].lines)
			{
				result.push_back({ DIFF_INSERT, CString(), line });
			}
		}
	}

	return result;
}
static std::vector<DiffLine> ComputeDiff(
	const std::vector<CString>& leftLines,
	const std::vector<CString>& rightLines)
{
	const int m = static_cast<int>(leftLines.size());
	const int n = static_cast<int>(rightLines.size());

	// ============================================================
	// LCS DP 테이블 생성
	// ============================================================

	std::vector<std::vector<int>> dp(
		m + 1,
		std::vector<int>(n + 1, 0)
	);

	for (int i = 1; i <= m; ++i)
	{
		for (int j = 1; j <= n; ++j)
		{
			if (leftLines[i - 1] == rightLines[j - 1])
			{
				dp[i][j] = dp[i - 1][j - 1] + 1;
			}
			else
			{
				dp[i][j] = (std::max)(
					dp[i - 1][j],
					dp[i][j - 1]
					);
			}
		}
	}


	// ============================================================
	// LCS Backtracking
	//
	// 결과는 역순으로 만들어짐
	// ============================================================

	std::vector<DiffLine> reverseResult;

	int i = m;
	int j = n;

	while (i > 0 || j > 0)
	{
		// --------------------------------------------------------
		// MATCH
		// --------------------------------------------------------
		if (i > 0 &&
			j > 0 &&
			leftLines[i - 1] == rightLines[j - 1])
		{
			reverseResult.push_back(
				{
					DIFF_MATCH,
					leftLines[i - 1],
					rightLines[j - 1]
				}
			);

			--i;
			--j;
		}

		// --------------------------------------------------------
		// INSERT
		//
		// 오른쪽 파일에만 존재
		// --------------------------------------------------------
		else if (j > 0 &&
			(i == 0 ||
				dp[i][j - 1] >= dp[i - 1][j]))
		{
			reverseResult.push_back(
				{
					DIFF_INSERT,
					CString(),
					rightLines[j - 1]
				}
			);

			--j;
		}

		// --------------------------------------------------------
		// DELETE
		//
		// 왼쪽 파일에만 존재
		// --------------------------------------------------------
		else if (i > 0)
		{
			reverseResult.push_back(
				{
					DIFF_DELETE,
					leftLines[i - 1],
					CString()
				}
			);

			--i;
		}
	}


	// ============================================================
	//  정방향으로 변환
	// ============================================================

	std::vector<DiffLine> rawResult;

	rawResult.reserve(reverseResult.size());

	for (auto it = reverseResult.rbegin();
		it != reverseResult.rend();
		++it)
	{
		rawResult.push_back(*it);
	}


	// ============================================================
	// 변경 영역 그룹화
	//
	// MATCH를 기준으로 구간을 나눔
	//
	// 예:
	//
	// MATCH
	// DELETE
	// DELETE
	// INSERT
	// INSERT
	// MATCH
	//
	// 위의 DELETE ~ INSERT 전체가 하나의 변경 블록
	// ============================================================

	std::vector<DiffLine> result;

	result.reserve(rawResult.size());

	size_t index = 0;

	while (index < rawResult.size())
	{
		// --------------------------------------------------------
		// MATCH
		// --------------------------------------------------------
		if (rawResult[index].type == DIFF_MATCH)
		{
			result.push_back(rawResult[index]);

			++index;

			continue;
		}


		// ========================================================
		// 변경 영역 시작
		// ========================================================

		std::vector<CString> deletedLines;
		std::vector<CString> insertedLines;


		// --------------------------------------------------------
		// MATCH가 나올 때까지 모든 DELETE / INSERT 수집
		// --------------------------------------------------------

		while (index < rawResult.size() &&
			rawResult[index].type != DIFF_MATCH)
		{
			if (rawResult[index].type == DIFF_DELETE)
			{
				deletedLines.push_back(
					rawResult[index].leftStr
				);
			}
			else if (rawResult[index].type == DIFF_INSERT)
			{
				insertedLines.push_back(
					rawResult[index].rightStr
				);
			}

			++index;
		}


		// ========================================================
		// 변경 영역을 행 단위로 정렬
		//
		// N:M
		// 1:N
		// N:1
		//
		// 모두 여기서 처리
		// ========================================================

		const size_t deleteCount = deletedLines.size();
		const size_t insertCount = insertedLines.size();

		const size_t maxCount =
			(std::max)(deleteCount, insertCount);


		for (size_t k = 0; k < maxCount; ++k)
		{
			const bool hasLeft =
				k < deleteCount;

			const bool hasRight =
				k < insertCount;


			// ----------------------------------------------------
			// 양쪽 모두 존재
			//
			// DELETE + INSERT
			// => CHANGE
			// ----------------------------------------------------
			if (hasLeft && hasRight)
			{
				result.push_back(
					{
						DIFF_CHANGE,
						deletedLines[k],
						insertedLines[k]
					}
				);
			}

			// ----------------------------------------------------
			// 왼쪽만 존재
			//
			// => DELETE
			// ----------------------------------------------------
			else if (hasLeft)
			{
				result.push_back(
					{
						DIFF_DELETE,
						deletedLines[k],
						CString()
					}
				);
			}

			// ----------------------------------------------------
			// 오른쪽만 존재
			//
			// => INSERT
			// ----------------------------------------------------
			else
			{
				result.push_back(
					{
						DIFF_INSERT,
						CString(),
						insertedLines[k]
					}
				);
			}
		}
	}


	return result;
}
#define ID_CAPTION_BAR 1600

// ==========================================
// 1. CDiffGridPaneView (왼쪽 뷰) 구현
// ==========================================
IMPLEMENT_DYNCREATE(CDiffGridPaneView, CView)

CDiffGridPaneView::CDiffGridPaneView()
{
}

CDiffGridPaneView::~CDiffGridPaneView()
{
	m_subFrameToolBar.RemoveAllButtons();
}

BEGIN_MESSAGE_MAP(CDiffGridPaneView, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_SUB_FILE_OPEN, &CDiffGridPaneView::OnToolbarFileOpen)
	ON_COMMAND(ID_SUB_FIX, &CDiffGridPaneView::OnNextChange)
	ON_COMMAND(ID_SUB_ADD, &CDiffGridPaneView::OnNextInsert)
	ON_COMMAND(ID_SUB_DELETE, &CDiffGridPaneView::OnNextDelete)
END_MESSAGE_MAP()

void CDiffGridPaneView::OnDraw(CDC* pDC)
{
	COLORREF clrText = globalData.clrWindowText;
	CRect rectClient;
	GetClientRect(rectClient);
	pDC->FillSolidRect(rectClient, CBCGPVisualManager::GetInstance()->GetControlFillColor());
	clrText = CBCGPVisualManager::GetInstance()->GetControlTextColor();
}

int CDiffGridPaneView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_subFrameToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;
	}

	if (!m_subFrameToolBar.LoadToolBar(IDR_SUBFRAME, 0, 0, FALSE, 0, 0, IDR_SVG1))
	{
		TRACE0("Failed to create view toolbar\n");
		return -1;
	}

	// 뷰 내부에 그리드 컨트롤(에디트) 생성
	m_wndLeftEditLDat.Create(WS_CHILD | WS_VISIBLE | WS_BORDER, CRect(0, 0, 0, 0), this, 1100);
	m_wndLeftEditLDat.SetModified(FALSE);
	m_wndLeftEditLDat.SetReadOnly(TRUE);
	return 0;
}

void CDiffGridPaneView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	if (m_subFrameToolBar.GetSafeHwnd())
	{
		CSize sizeTB = m_subFrameToolBar.CalcFixedLayout(FALSE, TRUE);
		m_subFrameToolBar.SetWindowPos(NULL, 0, 0, cx, sizeTB.cy, SWP_NOZORDER | SWP_NOACTIVATE);
		m_subFrameToolBar.RedrawWindow();
	}

	if (m_wndLeftEditLDat.GetSafeHwnd())
	{
		CSize sizeTB = m_subFrameToolBar.GetSafeHwnd() ? m_subFrameToolBar.CalcFixedLayout(FALSE, TRUE) : CSize(0, 0);
		m_wndLeftEditLDat.SetWindowPos(NULL, 0, sizeTB.cy, cx, cy - sizeTB.cy, SWP_NOZORDER | SWP_NOACTIVATE);
	}
	UpdateWindow();
}

CString CDiffGridPaneView::GetFileStationName(const CString& fileName)
{
	int nLastBackslash = fileName.ReverseFind(_T('\\'));
	CString strStationName = fileName.Mid(nLastBackslash + 1);
	int nUnderscore = strStationName.Find(_T("_"));
	if (nUnderscore != -1)
	{
		strStationName = strStationName.Left(nUnderscore);
	}
	else {
		BCGPMessageBox(_T("파일 명칭 형식 오류 발생"));
	}
	return strStationName;
}

void CDiffGridPaneView::OnToolbarFileOpen()
{
	CFileDialog dlg(
		TRUE,
		_T("bin"),
		NULL,
		OFN_FILEMUSTEXIST | OFN_HIDEREADONLY,
		_T("연동 데이터 (*.bin)|*_연동_데이터.bin||"),
		this
	);
	if (dlg.DoModal() == IDOK)
	{
		CString outPutMsg;
		CString strFilePath = dlg.GetPathName();
		bool result = DataLoader::LoadAllOriginalDataFromFolder(strFilePath, outPutMsg);
		if (!outPutMsg.IsEmpty())
		{
			CString resultMsg;
			resultMsg.Format(_T("%s 파일 로딩 실패"), (LPCTSTR)outPutMsg);
			BCGPMessageBox(resultMsg, MB_ICONWARNING);
		}
		CWnd* pParent = GetParentFrame();
		if (pParent && pParent->IsKindOf(RUNTIME_CLASS(DiffCompareFrame)))
		{
			if (((DiffCompareFrame*)pParent)->m_pWorkSpaceBar.SetTreeViewData())
			{
				BCGPMessageBox(_T("LDAT 파일 갱신 성공"), MB_ICONINFORMATION);
			}
			else
			{
				BCGPMessageBox(_T("LDAT 파일 갱신 실패"), MB_ICONWARNING);
			}
		}
	}
}
//
//void CDiffGridPaneView::SetLogicData(const std::vector<CString>& lines, const std::vector<DiffLine>& diffs)
//{
//	CString strAll;
//	for (const auto& line : lines) {
//		strAll += line + _T("\r\n");
//	}
//	m_wndLeftEditLDat.SetRedraw(FALSE);
//	m_wndLeftEditLDat.InsertText(strAll);
//	m_wndLeftEditLDat.SetRedraw(TRUE);
//
//	m_wndLeftEditLDat.InitDiffData(diffs, true);
//}


bool CDiffGridPaneView::ReadTextFileLines(const CString& filePath, std::vector<CString>& outLines)
{
	CFile file;
	CFileException ex;
	if (!file.Open(filePath, CFile::modeRead | CFile::shareDenyWrite, &ex))
	{
		return false;
	}

	ULONGLONG fileLen = file.GetLength();
	std::vector<char> buffer(static_cast<size_t>(fileLen) + 1, 0);
	file.Read(buffer.data(), static_cast<UINT>(fileLen));
	file.Close();

	CString strText(buffer.data());
	int nCurPos = 0;
	CString strLine;

	outLines.clear();
	while (!(strLine = strText.Tokenize(_T("\r\n"), nCurPos)).IsEmpty())
	{
		outLines.push_back(strLine);
	}

	return true;
}


// ==========================================
// 2. CDiffGridRightView (오른쪽 뷰) 구현
// ==========================================
IMPLEMENT_DYNCREATE(CDiffGridRightView, CView)

CDiffGridRightView::CDiffGridRightView()
{
	// [수정됨] 생성자에서 CView::OnDestroy() 호출 시 윈도우 핸들이 없어서 크래시 발생 가능성이 있으므로 제거합니다.
}

CDiffGridRightView::~CDiffGridRightView()
{
}

BEGIN_MESSAGE_MAP(CDiffGridRightView, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_SUB_FILE_OPEN, &CDiffGridRightView::OnToolbarFileOpen)
	ON_COMMAND(ID_SUB_FIX, &CDiffGridRightView::OnNextChange)
	ON_COMMAND(ID_SUB_ADD, &CDiffGridRightView::OnNextInsert)
	ON_COMMAND(ID_SUB_DELETE, &CDiffGridRightView::OnNextDelete)
END_MESSAGE_MAP()

void CDiffGridRightView::OnDraw(CDC* pDC)
{
	COLORREF clrText = globalData.clrWindowText;
	CRect rectClient;
	GetClientRect(rectClient);
	pDC->FillSolidRect(rectClient, CBCGPVisualManager::GetInstance()->GetControlFillColor());
	clrText = CBCGPVisualManager::GetInstance()->GetControlTextColor();
}

int CDiffGridRightView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_subFrameToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;
	}

	if (!m_subFrameToolBar.LoadToolBar(IDR_SUBFRAME, 0, 0, FALSE, 0, 0, IDR_SVG1))
	{
		TRACE0("Failed to create view toolbar\n");
		return -1;
	}


	m_wndRightEditLDat.Create(WS_CHILD | WS_VISIBLE | WS_BORDER, CRect(0, 0, 0, 0), this, 1100);
	m_wndRightEditLDat.SetModified(FALSE);
	m_wndRightEditLDat.SetReadOnly(TRUE);
	return 0;
}

void CDiffGridRightView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	if (m_subFrameToolBar.GetSafeHwnd())
	{
		CSize sizeTB = m_subFrameToolBar.CalcFixedLayout(FALSE, TRUE);
		m_subFrameToolBar.SetWindowPos(NULL, 0, 0, cx, sizeTB.cy, SWP_NOZORDER | SWP_NOACTIVATE);
		m_subFrameToolBar.RedrawWindow();
	}

	if (m_wndRightEditLDat.GetSafeHwnd())
	{
		CSize sizeTB = m_subFrameToolBar.GetSafeHwnd() ? m_subFrameToolBar.CalcFixedLayout(FALSE, TRUE) : CSize(0, 0);
		m_wndRightEditLDat.SetWindowPos(NULL, 0, sizeTB.cy, cx, cy - sizeTB.cy, SWP_NOZORDER | SWP_NOACTIVATE);
	}
}

void CDiffGridRightView::OnToolbarFileOpen()
{
	CFileDialog dlg(
		TRUE,
		_T("bin"),
		NULL,
		OFN_FILEMUSTEXIST | OFN_HIDEREADONLY,
		_T("연동 데이터 (*.bin)|*_연동_데이터.bin||"),
		this
	);
	if (dlg.DoModal() == IDOK)
	{
		CString OutputErrMsg;
		CString strFilePath = dlg.GetPathName();
		DataLoader::LoadAllDifflDataFromFolder(strFilePath, OutputErrMsg);

		if (!OutputErrMsg.IsEmpty())
		{
			CString resultMsg;
			resultMsg.Format(_T("%s 파일 로딩 실패"), (LPCTSTR)OutputErrMsg);
			BCGPMessageBox(resultMsg, MB_ICONWARNING);
		}

		CWnd* pParent = GetParent()->GetParentFrame();
		if (pParent != nullptr)
		{
			DiffCompareFrame* pDiffFrame = DYNAMIC_DOWNCAST(DiffCompareFrame, pParent);
			if (pDiffFrame != nullptr)
			{
				pDiffFrame->SetCaptionText(dlg.GetFileName());
			}
		}
	}
}

//void CDiffGridRightView::SetLogicData(const std::vector<CString>& lines, const std::vector<DiffLine>& diffs)
//{
//	CString strAll;
//	for (const auto& line : lines) {
//		strAll += line + _T("\r\n");
//	}
//	m_wndRightEditLDat.SetRedraw(FALSE);
//	m_wndRightEditLDat.InsertText(strAll);
//	m_wndRightEditLDat.SetRedraw(TRUE);
//
//	m_wndRightEditLDat.InitDiffData(diffs, false);
//}

// ==========================================
// 3. DiffCompareFrame 구현
// ==========================================
IMPLEMENT_DYNCREATE(DiffCompareFrame, CBCGPFrameWnd)

DiffCompareFrame::DiffCompareFrame()
	: m_ppParentPtr(nullptr)
	, m_CurrentChange(0)
	, m_CurrentDelete(0)
	, m_CurrnetAdd(0)
	, m_CurrentDiffRow(0)
{
	m_logicThread.Start();

}

DiffCompareFrame::~DiffCompareFrame()
{
	m_logicThread.Stop();
	m_pWorkSpaceBar.DestroyWindow();

}

BEGIN_MESSAGE_MAP(DiffCompareFrame, CBCGPFrameWnd)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_DESTROY()
	ON_NOTIFY(TVN_DELETEITEM, 1, &DiffCompareFrame::OnTvnDeleteItem)
	ON_WM_CLOSE()
	//ON_MESSAGE(WM_LOGIC_DIFF_FINISHED, &DiffCompareFrame::OnLogicFinished)
	//ON_MESSAGE(WM_RENDER_NEXT_CHUNK, &DiffCompareFrame::OnRenderNextChunk)
END_MESSAGE_MAP()

int DiffCompareFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CBCGPFrameWnd::OnCreate(lpCreateStruct) == -1) {
		return -1;
	}

	EnableDocking(CBRS_ALIGN_ANY);
	const int nPaneSize = globalUtils.ScaleByDPI(200, this);
	if (!m_pWorkSpaceBar.Create(_T("파일 비교"), this, CRect(0, 0, nPaneSize, nPaneSize), TRUE, ID_VIEW_WORKSPACE, WS_CHILD | WS_VISIBLE | CBRS_LEFT | CBRS_FLOAT_MULTI))
	{
		TRACE0("Failed to create WorkSpaceBar\n");
		return -1;
	}
	if (!m_wndCaptionBar.Create(WS_CHILD | WS_VISIBLE | CBRS_TOP, this, ID_CAPTION_BAR))
	{
		TRACE0("Failed to create captionBar\n");
		return -1;
	}

	m_wndCaptionBar.SetMessageBarMode(TRUE);

	m_pWorkSpaceBar.SetIconIndex(1);
	m_pWorkSpaceBar.EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_pWorkSpaceBar);

	return 0;
}

void DiffCompareFrame::OnSize(UINT nType, int cx, int cy)
{
	CBCGPFrameWnd::OnSize(nType, cx, cy);
	if (cx <= 0 || cy <= 0)
	{
		return;
	}

}

BOOL DiffCompareFrame::OnCreateClient(LPCREATESTRUCT /*lpcs*/, CCreateContext* pContext)
{
	CRect rect;
	GetClientRect(&rect);


	int nSplitterWidth = rect.Width();

	if (!m_wndSplitter.CreateStatic(this, 1, 2, WS_CHILD | WS_VISIBLE, AFX_IDW_PANE_FIRST))
	{
		return FALSE;
	}

	if (!m_wndSplitter.CreateView(0, 0, RUNTIME_CLASS(CDiffGridPaneView), CSize(nSplitterWidth / 2, rect.Height()), pContext))
	{
		return FALSE;
	}

	if (!m_wndSplitter.CreateView(0, 1, RUNTIME_CLASS(CDiffGridRightView), CSize(nSplitterWidth / 2, rect.Height()), pContext))
	{
		return FALSE;
	}

	m_wndSplitter.ShowWindow(SW_SHOW);
	m_wndSplitter.RedrawWindow();

	CWnd* pLeftView = m_wndSplitter.GetPane(0, 0);
	CWnd* pRightView = m_wndSplitter.GetPane(0, 1);

	if (pLeftView)
	{
		pLeftView->ShowWindow(SW_SHOW);
		pLeftView->RedrawWindow();
	}

	if (pRightView)
	{
		pRightView->ShowWindow(SW_SHOW);
		pRightView->RedrawWindow();
	}

	return TRUE;
}
CustomBCGPEditCtrl* DiffCompareFrame::GetLeftEdit()
{
	CDiffGridPaneView* pView = (CDiffGridPaneView*)m_wndSplitter.GetPane(0, 0);
	if (pView) return &pView->m_wndLeftEditLDat;
	return nullptr;
}

CustomBCGPEditCtrl* DiffCompareFrame::GetRightEdit()
{
	CDiffGridRightView* pView = (CDiffGridRightView*)m_wndSplitter.GetPane(0, 1);
	if (pView) return &pView->m_wndRightEditLDat;
	return nullptr;
}
// 텍스트에서 '명칭=' 부분의 '명칭(Key)'만 추출하는 도우미 함수

void DiffCompareFrame::SetCaptionText(CString strCaption)
{
	//m_wndCaptionBar.SetText(strCaption, ALIGN_CENTER);
}

void DiffCompareFrame::PostNcDestroy()
{
	if (m_ppParentPtr != nullptr)
	{
		*m_ppParentPtr = nullptr;
		m_ppParentPtr = nullptr;
	}
	CBCGPFrameWnd::PostNcDestroy();
}


void DiffCompareFrame::OnClose()
{
	CBCGPFrameWnd::OnClose();
}
void DiffCompareFrame::OnTvnDeleteItem(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);
	if (pNMTreeView != nullptr)
	{
		// 트리에 저장해 둔 동적 할당 CString 포인터 안전하게 해제
		CString* pSavedPath = reinterpret_cast<CString*>(pNMTreeView->itemOld.lParam);
		if (pSavedPath != nullptr)
		{
			delete pSavedPath;
			pSavedPath = nullptr;
		}
	}
	*pResult = 0;
}

void DiffCompareFrame::OnDestroy()
{
	CFrameWnd::OnDestroy(); // 상속받으신 프레임 기본 클래스에 맞게 호출

	// 프레임이 파괴될 때 트리의 모든 아이템을 비워주어 TVN_DELETEITEM을 유발하고 메모리 누수를 방지합니다.
	m_pWorkSpaceBar.DeleteAllItems();
}

void DiffCompareFrame::CompareLDATFiles(
	const CString& originalPath,
	const CString& diffPath)
{
	// ============================================================
	// 1. View 가져오기
	// ============================================================
	CDiffGridPaneView* pLeftView =
		DYNAMIC_DOWNCAST(CDiffGridPaneView, m_wndSplitter.GetPane(0, 0));

	CDiffGridRightView* pRightView =
		DYNAMIC_DOWNCAST(CDiffGridRightView, m_wndSplitter.GetPane(0, 1));

	if (pLeftView == nullptr || pRightView == nullptr)
	{
		TRACE(_T("[Diff] View NULL\n"));
		return;
	}

	// ============================================================
	// 2. Edit Control
	// ============================================================
	CustomBCGPEditCtrl* pLeftEdit = &pLeftView->m_wndLeftEditLDat;
	CustomBCGPEditCtrl* pRightEdit = &pRightView->m_wndRightEditLDat;

	if (pLeftEdit == nullptr || pRightEdit == nullptr)
	{
		return;
	}

	// ============================================================
	// 3. 비교 작업 중 Peer 연결 해제 (이벤트 상호 간섭 방지)
	// ============================================================
	pLeftEdit->m_pPeerEdit = nullptr;
	pRightEdit->m_pPeerEdit = nullptr;

	// ============================================================
	// 4. 파일 읽기
	// ============================================================
	std::vector<CString> leftLines;
	std::vector<CString> rightLines;

	pLeftView->ReadTextFileLines(originalPath, leftLines);
	pLeftView->ReadTextFileLines(diffPath, rightLines);

	// ============================================================
	// 5. Diff 계산
	// ============================================================
	m_diffResults = ComputeDiff(leftLines, rightLines);

	// ============================================================
	// 6. Diff 개수 초기화
	// ============================================================
	m_CurrentChange = 0;
	m_CurrentDelete = 0;
	m_CurrnetAdd = 0;
	m_CurrentDiffRow = -1;

	for (const auto& diff : m_diffResults)
	{
		switch (diff.type)
		{
		case DIFF_CHANGE:
			++m_CurrentChange;
			break;

		case DIFF_DELETE:
			++m_CurrentDelete;
			break;

		case DIFF_INSERT:
			++m_CurrnetAdd;
			break;

		default:
			break;
		}
	}

	//TRACE(
	//	_T("[Diff] Change=%d Delete=%d Insert=%d TotalRows=%d\n"),
	//	m_CurrentChange,
	//	m_CurrentDelete,
	//	m_CurrnetAdd,
	//	static_cast<int>(m_diffResults.size()));

	// ============================================================
	// 7. 기존 Line Marker 제거
	// ============================================================
	pLeftEdit->DeleteAllMarkers(g_dwBCGPEdit_LineColorMarker, FALSE);
	pRightEdit->DeleteAllMarkers(g_dwBCGPEdit_LineColorMarker, FALSE);

	// ============================================================
	// 8. 좌우 정렬된 텍스트 생성 (diffResults 1개 = 1행)
	// ============================================================
	CString alignedLeftText;
	CString alignedRightText;

	const size_t totalDiffCount = m_diffResults.size();
	for (size_t i = 0; i < totalDiffCount; ++i)
	{
		const DiffLine& diff = m_diffResults[i];

		// LEFT
		alignedLeftText += diff.leftStr;
		if (i + 1 < totalDiffCount)
		{
			alignedLeftText += _T("\r\n");
		}

		// RIGHT
		alignedRightText += diff.rightStr;
		if (i + 1 < totalDiffCount)
		{
			alignedRightText += _T("\r\n");
		}
	}
	pLeftEdit->SetWindowText(_T(""));
	pRightEdit->SetWindowText(_T(""));

	pLeftEdit->ResetScrollPosition();
	pRightEdit->ResetScrollPosition();
	// ============================================================
	// 9. Edit 내용 설정
	// ============================================================
	pLeftEdit->SetWindowText(alignedLeftText);
	pRightEdit->SetWindowText(alignedRightText);

	// ============================================================
	// 10. 스크롤 위치 초기화
	// ============================================================
	pLeftEdit->ResetScrollPosition();
	pRightEdit->ResetScrollPosition();

	// ============================================================
	// 11. 줄 색상 Marker 설정
	// ============================================================
	const DWORD dwDefText = (DWORD)-1;
	const COLORREF clrChange = RGB(255, 255, 200);
	const COLORREF clrDelete = RGB(255, 200, 200);
	const COLORREF clrInsert = RGB(200, 255, 200);
	const COLORREF clrEmpty = RGB(240, 240, 240);

	for (int row = 0; row < static_cast<int>(totalDiffCount); ++row)
	{
		const DiffLine& diff = m_diffResults[row];

		switch (diff.type)
		{
		case DIFF_MATCH:
			break;

		case DIFF_CHANGE:
			pLeftEdit->SetLineColorMarker(row, dwDefText, clrChange, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
			pRightEdit->SetLineColorMarker(row, dwDefText, clrChange, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
			break;

		case DIFF_DELETE:
			pLeftEdit->SetLineColorMarker(row, dwDefText, clrDelete, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
			pRightEdit->SetLineColorMarker(row, dwDefText, clrEmpty, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
			break;

		case DIFF_INSERT:
			pLeftEdit->SetLineColorMarker(row, dwDefText, clrEmpty, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
			pRightEdit->SetLineColorMarker(row, dwDefText, clrInsert, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
			break;
		}
	}

	// ============================================================
	// 12. 스크롤 맨 위 / 맨 왼쪽으로 이동
	// ============================================================
	pLeftEdit->SendMessage(WM_VSCROLL, SB_TOP, 0);
	pRightEdit->SendMessage(WM_VSCROLL, SB_TOP, 0);

	pLeftEdit->SendMessage(WM_HSCROLL, SB_LEFT, 0);
	pRightEdit->SendMessage(WM_HSCROLL, SB_LEFT, 0);

	// ============================================================
	// 13. Diff Scrollbar Marker 전달
	// ============================================================
	std::vector<DiffScrollMarker> scrollMarkers;
	const int nTotalRows = static_cast<int>(totalDiffCount);

	for (int row = 0; row < nTotalRows; ++row)
	{
		COLORREF color;
		bool bIsDiff = true;

		switch (m_diffResults[row].type)
		{
		case DIFF_CHANGE:
			color = RGB(255, 255, 0);   // 노랑
			break;

		case DIFF_DELETE:
			color = RGB(255, 80, 80);   // 빨강
			break;

		case DIFF_INSERT:
			color = RGB(80, 220, 80);   // 초록
			break;

		default:
			bIsDiff = false;
			break;
		}

		if (bIsDiff)
		{
			scrollMarkers.push_back(DiffScrollMarker(row, color));
		}
	}

	pLeftEdit->SetDiffScrollMarkers(scrollMarkers, nTotalRows);
	pRightEdit->SetDiffScrollMarkers(scrollMarkers, nTotalRows);

	// ============================================================
	// 14. UI / 상태바 요약 정보 갱신 (추가됨)
	// ============================================================
	// 필요 시 프레임의 상태바나 카운터 UI 컨트롤 갱신 함수 호출
	// UpdateDiffStatusUI(m_CurrentChange, m_CurrentDelete, m_CurrnetAdd);

	// ============================================================
	// 15. 스크롤바 영역 재계산 (추가됨)
	// ============================================================
	pLeftEdit->UpdateScrollBars();
	pRightEdit->UpdateScrollBars();

	// ============================================================
	// 16. Edit 화면 갱신
	// ============================================================
	pLeftEdit->RedrawWindow(NULL, NULL, RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE);
	pRightEdit->RedrawWindow(NULL, NULL, RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE);

	// ============================================================
	// 17. Peer 연결 (양방향 스크롤 동기화 복구)
	// ============================================================
	pLeftEdit->m_pPeerEdit = pRightEdit;
	pRightEdit->m_pPeerEdit = pLeftEdit;

	//TRACE(_T("[Diff] CompareLDATFiles END\n"));
}
void DiffCompareFrame::ApplyDiffToUI(const std::vector<CString>& leftLines, const std::vector<CString>& rightLines)
{
	CDiffGridPaneView* pLeftView = DYNAMIC_DOWNCAST(CDiffGridPaneView, m_wndSplitter.GetPane(0, 0));
	CDiffGridRightView* pRightView = DYNAMIC_DOWNCAST(CDiffGridRightView, m_wndSplitter.GetPane(0, 1));
	if (!pLeftView || !pRightView) return;

	CustomBCGPEditCtrl* pLeftEdit = &pLeftView->m_wndLeftEditLDat;
	CustomBCGPEditCtrl* pRightEdit = &pRightView->m_wndRightEditLDat;

	pLeftEdit->m_pPeerEdit = nullptr;
	pRightEdit->m_pPeerEdit = nullptr;


	m_diffResults = ComputeBinDiff(leftLines, rightLines);

	m_CurrentChange = 0;
	m_CurrentDelete = 0;
	m_CurrnetAdd = 0;
	m_CurrentDiffRow = -1;

	for (auto& diff : m_diffResults) {
		switch (diff.type)
		{
		case DIFF_CHANGE:
			++m_CurrentChange;
			break;
		case DIFF_DELETE:
			++m_CurrentDelete;
			break;
		case DIFF_INSERT:
			++m_CurrnetAdd;
			break;
		default:
			break;
		}
	}

	pLeftEdit->DeleteAllMarkers(g_dwBCGPEdit_LineColorMarker, FALSE);
	pRightEdit->DeleteAllMarkers(g_dwBCGPEdit_LineColorMarker, FALSE);

	CString alignedLeftText, alignedRightText;
	const size_t totalDiffCount = m_diffResults.size();
	for (size_t i = 0; i < totalDiffCount; ++i)
	{
		alignedLeftText += m_diffResults[i].leftStr;
		alignedRightText += m_diffResults[i].rightStr;

		if (i + 1 < totalDiffCount)
		{
			alignedLeftText += _T("\r\n");
			alignedRightText += _T("\r\n");
		}
	}

	pLeftEdit->SetWindowText(_T(""));
	pRightEdit->SetWindowText(_T(""));
	pLeftEdit->SetWindowText(alignedLeftText);
	pRightEdit->SetWindowText(alignedRightText);
	pLeftEdit->ResetScrollPosition();
	pRightEdit->ResetScrollPosition();

	// 색상 및 마커 처리 로직은 기존과 동일하게 유지
	const DWORD dwDefText = (DWORD)-1;
	const COLORREF clrChange = RGB(255, 255, 200), clrDelete = RGB(255, 200, 200);
	const COLORREF clrInsert = RGB(200, 255, 200), clrEmpty = RGB(240, 240, 240);
	std::vector<DiffScrollMarker> scrollMarkers;

	for (int row = 0; row < static_cast<int>(totalDiffCount); ++row)
	{
		COLORREF scrollColor = 0;
		bool bHasDiff = true;

		switch (m_diffResults[row].type)
		{
		case DIFF_CHANGE:
			pLeftEdit->SetLineColorMarker(row, dwDefText, clrChange, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
			pRightEdit->SetLineColorMarker(row, dwDefText, clrChange, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
			scrollColor = RGB(255, 255, 0); break;
		case DIFF_DELETE:
			pLeftEdit->SetLineColorMarker(row, dwDefText, clrDelete, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
			pRightEdit->SetLineColorMarker(row, dwDefText, clrEmpty, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
			scrollColor = RGB(255, 80, 80); break;
		case DIFF_INSERT:
			pLeftEdit->SetLineColorMarker(row, dwDefText, clrEmpty, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
			pRightEdit->SetLineColorMarker(row, dwDefText, clrInsert, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
			scrollColor = RGB(80, 220, 80); break;
		default:
			bHasDiff = false; break;
		}

		if (bHasDiff) scrollMarkers.push_back(DiffScrollMarker(row, scrollColor));
	}

	pLeftEdit->SetDiffScrollMarkers(scrollMarkers, static_cast<int>(totalDiffCount));
	pRightEdit->SetDiffScrollMarkers(scrollMarkers, static_cast<int>(totalDiffCount));

	pLeftEdit->SendMessage(WM_VSCROLL, SB_TOP, 0);
	pRightEdit->SendMessage(WM_VSCROLL, SB_TOP, 0);
	pLeftEdit->SendMessage(WM_HSCROLL, SB_LEFT, 0);
	pRightEdit->SendMessage(WM_HSCROLL, SB_LEFT, 0);

	pLeftEdit->UpdateScrollBars();
	pRightEdit->UpdateScrollBars();

	pLeftEdit->RedrawWindow(NULL, NULL, RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE);
	pRightEdit->RedrawWindow(NULL, NULL, RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE);

	pLeftEdit->m_pPeerEdit = pRightEdit;
	pRightEdit->m_pPeerEdit = pLeftEdit;
}
// 트리뷰 등에서 파일 선택 시 불려지는 메인 진입점
void DiffCompareFrame::ProcessLdatSelection(const CString& fileName, const CString& clickedOriginalPath)
{
	CWaitCursor wait;

	auto& dataComp = DataComparison::GetInstance();

	const auto& originalList = dataComp.GetOriginalLDAT();
	const auto& diffList = dataComp.GetDiffLDAT();

	CString diffPath = _T("");
	bool bFoundDiff = false;

	// ============================================================
	// 1. 비교 대상 파일 찾기
	// ============================================================
	for (const auto& path : diffList)
	{
		int idx = path.ReverseFind(_T('\\'));
		CString diffFileName =
			(idx != -1) ? path.Mid(idx + 1) : path;

		if (diffFileName.CompareNoCase(fileName) == 0)
		{
			diffPath = path;
			bFoundDiff = true;
			break;
		}
	}

	CDiffGridPaneView* pLeftView =
		DYNAMIC_DOWNCAST(
			CDiffGridPaneView,
			m_wndSplitter.GetPane(0, 0));

	CDiffGridRightView* pRightView =
		DYNAMIC_DOWNCAST(
			CDiffGridRightView,
			m_wndSplitter.GetPane(0, 1));

	// ============================================================
	// 2. 비교 대상 파일이 없는 경우
	// ============================================================
	if (!bFoundDiff)
	{
		m_wndCaptionBar.SetText(fileName);

		if (pLeftView != nullptr)
		{
			pLeftView->m_wndLeftEditLDat.SetWindowText(_T(""));
			pRightView->m_wndRightEditLDat.SetWindowText(_T(""));
			pLeftView->m_wndLeftEditLDat.InsertText(
				_T("비교 대상 파일이 없습니다."));

		}

		return;
	}

	// ============================================================
	// 3. 비교 실행
	// ============================================================
	if (pLeftView != nullptr && pRightView != nullptr)
	{
		CompareLDATFiles(
			clickedOriginalPath,
			diffPath);
	}

	// ============================================================
	// 4. Caption에 전체 Diff 개수 표시
	// ============================================================
	CString caption;
	caption.Format(
		_T("%s    |    수정: %d    삭제: %d    추가: %d"),
		(LPCTSTR)fileName,
		m_CurrentChange,
		m_CurrentDelete,
		m_CurrnetAdd);

	m_wndCaptionBar.SetText(caption);
}
void DiffCompareFrame::ProcessLogicDiffSelection(CString& logicType) {
	logicType.Trim(); // 좌우 공백 제거 (트리 텍스트의 여백 대비)

	UCHAR logicKind = 0;

	if (logicType == _T("속도코드제어장치 VRD"))      logicKind = _T('V');
	else if (logicType == _T("궤도"))                 logicKind = _T('T');
	else if (logicType == _T("선로전환기"))           logicKind = _T('P');
	else if (logicType == _T("신호기"))               logicKind = _T('S');
	else if (logicType == _T("LMR"))                  logicKind = _T('L');
	else if (logicType == _T("진로"))                 logicKind = _T('R');
	else if (logicType == _T("역공통"))               logicKind = _T('N');
	else if (logicType == _T("폐색"))                 logicKind = _T('B');
	else if (logicType == _T("건널목 - 고장검지"))    logicKind = _T('C');
	else if (logicType == _T("건널목 - 제어건널목"))  logicKind = _T('c');
	else if (logicType == _T("타역 궤도"))            logicKind = _T('t');
	else if (logicType == _T("타역 신호기"))          logicKind = _T('s');
	else if (logicType == _T("타역 선로전환기"))      logicKind = _T('p');
	else if (logicType == _T("전차선 절연구간"))      logicKind = _T('D');
	else if (logicType == _T("지장물"))               logicKind = _T('J');
	else if (logicType == _T("출발반응등"))           logicKind = _T('K');
	else if (logicType == _T("기타 고장"))            logicKind = _T('F');
	else if (logicType == _T("소속역 정보"))          logicKind = _T('W');
	else if (logicType == _T("CPT"))                  logicKind = _T('H');
	else if (logicType == _T("히터"))                 logicKind = _T('h');
	else if (logicType == _T("연동장치 정보"))        logicKind = _T('E');
	else {
		return; // 매칭되는 타입이 없을 경우 종료
	}

	SetLogicInfo(logicKind);
}
void DiffCompareFrame::ProcessBinDiffSelection(const CString& type)
{
	CWaitCursor wait;

	std::vector<CString> OriginalLine;
	std::vector<CString> DiffLine;

	if (type == _T("역") || type == _T("연동도표(진로 정보)") || type == _T("궤도") ||
		type == _T("신호기") || type == _T("선로전환기") || type == _T("폐색") ||
		type == _T("기타 고장 정보 및 출발 반응등") ||
		type == _T("입력카드 및 카드 Addr") || type == _T("") || type == _T("CPT") ||
		type == _T("DWELL") || type == _T("제어 건널목") || type == _T("INCardList") ||
		type == _T("OutCardList"))
	{
		ResetEditContent();
	}

	if (type == _T("역"))
	{
		SetStationInfo();
	}
	else if (type == _T("연동도표(진로 정보)")) { //연동도표
		SetInterLock();
	}
	else if (type == _T("궤도")) { // 궤도
		SetTrackInfo();
	}
	else if (type == _T("신호기")) { // 신호기
		SetSignalInfo();
	}
	else if (type == _T("선로전환기")) { //선로전환기
		SetSwitchInfo();
	}
	else if (type == _T("폐색")) { //폐색
		SetBlockInfo();
	}
	else if (type == _T("기타 고장 정보 및 출발 반응등")) {
		SetAllFaultInfo();
	}
	else if (type == _T("입력카드 및 카드 Addr")) {
		SetAllIOCardInfo();
	}
	else if (type == _T("CPT")) {
		SetCPTInfo();
	}
	else if (type == _T("DWELL")) {
		SetDWELLInfo();
	}
	else if (type == _T("INCardList")) {
		SetIncardInfo();
	}
	else if (type == _T("OutCardList")) {
		SetOutCardInfo();
	}


}

// ============================================================
// 현재 실제 ScrollBar 위치를 기준으로 다음 Diff 검색
// ============================================================
void DiffCompareFrame::FindNextDiff(DiffType type)
{
	if (m_diffResults.empty())
	{
		BCGPMessageBox(
			_T("비교 결과가 없습니다."),
			MB_OK | MB_ICONINFORMATION);
		return;
	}

	CDiffGridPaneView* pLeftView =
		DYNAMIC_DOWNCAST(
			CDiffGridPaneView,
			m_wndSplitter.GetPane(0, 0));

	if (pLeftView == nullptr)
		return;

	CustomBCGPEditCtrl* pEdit =
		&pLeftView->m_wndLeftEditLDat;

	if (pEdit == nullptr || !::IsWindow(pEdit->GetSafeHwnd()))
		return;

	// ★ 핵심:
	// 마지막으로 이동했던 Diff 행을 기준으로 하지 않는다.
	// 실제 현재 ScrollBar의 첫 표시 행을 기준으로 검색한다.
	const int nCurrentScroll =
		pEdit->GetFirstVisibleLine();

	// 현재 화면의 첫 행보다 뒤에 있는 항목을 찾는다.
	for (int i = nCurrentScroll + 1;
		i < static_cast<int>(m_diffResults.size());
		++i)
	{
		if (m_diffResults[i].type == type)
		{
			m_CurrentDiffRow = i;
			MoveToDiffRow(i);
			return;
		}
	}

	// ★ 순환하지 않는다.
	// 마지막 항목에 도착했으면 알림만 표시한다.
	ShowDiffEndMessage(type, false);
}

// ============================================================
// 현재 실제 ScrollBar 위치를 기준으로 이전 Diff 검색
// ============================================================
void DiffCompareFrame::FindPrevDiff(DiffType type)
{
	if (m_diffResults.empty())
	{
		BCGPMessageBox(
			_T("비교 결과가 없습니다."),
			MB_OK | MB_ICONINFORMATION);
		return;
	}

	CDiffGridPaneView* pLeftView =
		DYNAMIC_DOWNCAST(
			CDiffGridPaneView,
			m_wndSplitter.GetPane(0, 0));

	if (pLeftView == nullptr)
		return;

	CustomBCGPEditCtrl* pEdit =
		&pLeftView->m_wndLeftEditLDat;

	if (pEdit == nullptr || !::IsWindow(pEdit->GetSafeHwnd()))
		return;

	// 실제 ScrollBar의 첫 표시 행을 기준으로 이전 항목 검색
	const int nCurrentScroll =
		pEdit->GetFirstVisibleLine();

	for (int i = nCurrentScroll - 1;
		i >= 0;
		--i)
	{
		if (m_diffResults[i].type == type)
		{
			m_CurrentDiffRow = i;
			MoveToDiffRow(i);
			return;
		}
	}

	// ★ 순환하지 않는다.
	ShowDiffEndMessage(type, true);
}

// ============================================================
// 다음/이전 검색 종료 메시지
// ============================================================
void DiffCompareFrame::ShowDiffEndMessage(
	DiffType type,
	bool bPrevious)
{
	CString typeName;

	switch (type)
	{
	case DIFF_CHANGE:
		typeName = _T("수정");
		break;

	case DIFF_DELETE:
		typeName = _T("삭제");
		break;

	case DIFF_INSERT:
		typeName = _T("추가");
		break;

	default:
		return;
	}

	CString message;

	if (bPrevious)
	{
		message.Format(
			_T("첫 번째 %s 항목입니다.\n\n")
			_T("전체 수정 : %d\n")
			_T("전체 삭제 : %d\n")
			_T("전체 추가 : %d"),
			(LPCTSTR)typeName,
			m_CurrentChange,
			m_CurrentDelete,
			m_CurrnetAdd);
	}
	else
	{
		message.Format(
			_T("마지막 %s 항목입니다.\n\n")
			_T("전체 수정 : %d\n")
			_T("전체 삭제 : %d\n")
			_T("전체 추가 : %d"),
			(LPCTSTR)typeName,
			m_CurrentChange,
			m_CurrentDelete,
			m_CurrnetAdd);
	}

	BCGPMessageBox(
		message,
		MB_OK | MB_ICONINFORMATION);
}

// ============================================================
// 찾은 Diff 행으로 화면 이동
//
//  검색 기준은 ScrollBar
//  이동 대상은 찾은 Diff 행
//  좌우 Edit는 한 번의 이동으로 동기화
// ============================================================
void DiffCompareFrame::MoveToDiffRow(int nRow)
{
	if (nRow < 0 ||
		nRow >= static_cast<int>(m_diffResults.size()))
	{
		return;
	}

	CDiffGridPaneView* pLeftView =
		DYNAMIC_DOWNCAST(
			CDiffGridPaneView,
			m_wndSplitter.GetPane(0, 0));

	CDiffGridRightView* pRightView =
		DYNAMIC_DOWNCAST(
			CDiffGridRightView,
			m_wndSplitter.GetPane(0, 1));

	if (pLeftView == nullptr ||
		pRightView == nullptr)
	{
		return;
	}

	CustomBCGPEditCtrl* pLeftEdit =
		&pLeftView->m_wndLeftEditLDat;

	CustomBCGPEditCtrl* pRightEdit =
		&pRightView->m_wndRightEditLDat;

	if (!::IsWindow(pLeftEdit->GetSafeHwnd()) ||
		!::IsWindow(pRightEdit->GetSafeHwnd()))
	{
		return;
	}

	const int nLeftFirst =
		pLeftEdit->GetFirstVisibleLine();

	const int nRightFirst =
		pRightEdit->GetFirstVisibleLine();

	// 찾은 행을 각 Edit의 첫 번째 표시 행으로 이동한다.
	const int nLeftDelta =
		nRow - nLeftFirst;

	const int nRightDelta =
		nRow - nRightFirst;

	// ------------------------------------------------------------
	// 기존 OnVScroll의 Peer 동기화가 다시 실행되지 않도록
	// 이동 중에는 m_bIsScrolling을 TRUE로 설정
	// ------------------------------------------------------------
	pLeftEdit->m_bIsScrolling = true;
	pRightEdit->m_bIsScrolling = true;

	if (nLeftDelta != 0)
	{
		pLeftEdit->LineScroll(nLeftDelta);
	}

	if (nRightDelta != 0)
	{
		pRightEdit->LineScroll(nRightDelta);
	}

	pLeftEdit->m_bIsScrolling = false;
	pRightEdit->m_bIsScrolling = false;

	// 현재 선택된 Diff 행은 UI 상태 표시용으로만 저장한다.
	// 다음 검색의 기준으로 사용하지 않는다.
	m_CurrentDiffRow = nRow;

	pLeftEdit->RedrawWindow(
		NULL,
		NULL,
		RDW_INVALIDATE | RDW_UPDATENOW);

	pRightEdit->RedrawWindow(
		NULL,
		NULL,
		RDW_INVALIDATE | RDW_UPDATENOW);
}

void DiffCompareFrame::ResetEditContent()
{
	CustomBCGPEditCtrl* pLeftEdit = GetLeftEdit();
	CustomBCGPEditCtrl* pRightEdit = GetRightEdit();
	pLeftEdit->SetWindowText(_T(""));
	pRightEdit->SetWindowText(_T(""));
}

// ============================================================
// LEFT VIEW TOOLBAR
// ============================================================
void CDiffGridPaneView::OnNextChange()
{
	DiffCompareFrame* pFrame =
		DYNAMIC_DOWNCAST(
			DiffCompareFrame,
			GetParentFrame());

	if (pFrame == nullptr)
		return;

	pFrame->FindNextDiff(DIFF_CHANGE);
}

void CDiffGridPaneView::OnNextDelete()
{
	DiffCompareFrame* pFrame =
		DYNAMIC_DOWNCAST(
			DiffCompareFrame,
			GetParentFrame());

	if (pFrame == nullptr)
		return;

	pFrame->FindNextDiff(DIFF_DELETE);
}

void CDiffGridPaneView::OnNextInsert()
{
	DiffCompareFrame* pFrame =
		DYNAMIC_DOWNCAST(
			DiffCompareFrame,
			GetParentFrame());

	if (pFrame == nullptr)
		return;

	pFrame->FindNextDiff(DIFF_INSERT);
}

// ============================================================
// RIGHT VIEW TOOLBAR
// ============================================================
void CDiffGridRightView::OnNextChange()
{
	DiffCompareFrame* pFrame =
		DYNAMIC_DOWNCAST(
			DiffCompareFrame,
			GetParentFrame());

	if (pFrame == nullptr)
		return;

	pFrame->FindNextDiff(DIFF_CHANGE);
}

void CDiffGridRightView::OnNextDelete()
{
	DiffCompareFrame* pFrame =
		DYNAMIC_DOWNCAST(
			DiffCompareFrame,
			GetParentFrame());

	if (pFrame == nullptr)
		return;

	pFrame->FindNextDiff(DIFF_DELETE);
}

void CDiffGridRightView::OnNextInsert()
{
	DiffCompareFrame* pFrame =
		DYNAMIC_DOWNCAST(
			DiffCompareFrame,
			GetParentFrame());

	if (pFrame == nullptr)
		return;

	pFrame->FindNextDiff(DIFF_INSERT);
}
void DiffCompareFrame::SetStationInfo()
{
	auto& dc = DataComparison::GetInstance();

	std::vector<CString> leftLines;
	std::vector<CString> rightLines;

	const bool hasOrigin = dc.HasOriginal();
	const bool hasDiff = dc.HasDiff();

	// 1. 둘 다 데이터가 없으면 중단
	if (!hasOrigin && !hasDiff)
	{
		return;
	}

	// 2. 원본(Left) 데이터 수집 및 예외 처리
	if (hasOrigin)
	{
		auto stationInfo = dc.GetOriginalStation();
		leftLines = ConvertStationInfoText(stationInfo);
	}
	else
	{
		leftLines.push_back(_T("선택한 파일이 없습니다."));
	}

	// 3. 비교군(Right) 데이터 수집 및 예외 처리
	if (hasDiff)
	{
		auto diffStationInfo = dc.GetDiffStation();
		rightLines = ConvertStationInfoText(diffStationInfo);
	}
	else
	{
		rightLines.push_back(_T("비교할 파일이 없습니다."));
	}

	// 4. 수집된 라인을 전달하여 [Diff 정렬 -> 화면 출력 -> 색상 하이라이트] 일괄 처리
	ApplyDiffToUI(leftLines, rightLines);
}
std::vector<CString> DiffCompareFrame::ConvertStationInfoText(StationInfoType stn) {

	std::vector<CString> lines;
	CString temp;

	lines.push_back(_T("========================================"));
	lines.push_back(_T("              [역 정보]                 "));
	lines.push_back(_T("----------------------------------------"));

	// 1. 기본 식별 번호 (모든 항목 고정 출력)
	temp.Format(_T("StationNo  : %d"), stn.StationNo); lines.push_back(temp);
	temp.Format(_T("LdtsNo     : %d"), stn.LdtsNo); lines.push_back(temp);
	temp.Format(_T("LctcStnNo  : %d"), stn.LctcStnNo); lines.push_back(temp);
	temp.Format(_T("RbcStnNo   : %d"), stn.RbcStnNo); lines.push_back(temp);

	// 2. StationInfo.Value 플래그 (모든 플래그를 ON/OFF로 고정 출력)
	lines.push_back(_T("")); // 여백 줄 분리
	lines.push_back(_T("--- [역 상태 정보] ---"));
	auto printFlag = [&](bool bOn, LPCTSTR desc) {
		temp.Format(_T(" - [%s] %s"), bOn ? _T("ON ") : _T("OFF"), desc);
		lines.push_back(temp);
		};

	printFlag(IsBitSet(stn.StationInfo.Value.IsCtc, 0), _T("CTC 역 여부"));
	printFlag(IsBitSet(stn.StationInfo.Value.IsCtcStd, 0), _T("CTC 표준프로토콜"));
	printFlag(IsBitSet(stn.StationInfo.Value.IsCtcStd2, 0), _T("CTC 개정프로토콜"));
	printFlag(IsBitSet(stn.StationInfo.Value.IsRcCtrl, 0), _T("원격제어"));
	printFlag(IsBitSet(stn.StationInfo.Value.LocalCTC, 0), _T("집중화장치"));
	printFlag(IsBitSet(stn.StationInfo.Value.LCtcMain, 0), _T("집중화 거점역"));
	printFlag(IsBitSet(stn.StationInfo.Value.TniUse, 0), _T("열번인식기"));
	printFlag(IsBitSet(stn.StationInfo.Value.LmcUse, 0), _T("체류보수"));
	printFlag(IsBitSet(stn.StationInfo.Value.SupportUse, 0), _T("전기설비 기술지원"));
	printFlag(IsBitSet(stn.StationInfo.Value.RbcUse, 0), _T("RBC통신"));
	printFlag(IsBitSet(stn.StationInfo.Value.CptStn, 0), _T("CPT 진입방지"));
	printFlag(IsBitSet(stn.StationInfo.Value.IsControlLC, 0), _T("건널목 출력 제어"));
	printFlag(IsBitSet(stn.StationInfo.Value.StnKind, 0), _T("연동역"));

	// 3. StationEquip.Value 장비 설정 플래그 (모두 고정 출력)
	lines.push_back(_T("")); // 여백 줄 분리
	lines.push_back(_T("--- [역 장비 정보] ---"));
	printFlag(IsBitSet(stn.StationEquip.Value.IsEIsFuse, 0), _T("연동논리부 FUSE 있음"));
	printFlag(IsBitSet(stn.StationEquip.Value.IsUpsAc, 0), _T("UPS AC전원 정상"));
	printFlag(IsBitSet(stn.StationEquip.Value.IsUpsAc, 1), _T("UPS AC전원 장애"));
	printFlag(IsBitSet(stn.StationEquip.Value.SigLmrKind, 0), _T("신호기 고장검지 1회선"));
	printFlag(IsBitSet(stn.StationEquip.Value.EtcEquip, 0), _T("히터 개정 전 동작설정"));

	// 4. 통신 및 설비 수량 정보 (0이어도 생략하지 않고 고정 출력)
	lines.push_back(_T("")); // 여백 줄 분리
	lines.push_back(_T("--- [장비 수] ---"));
	temp.Format(_T(" - 관제통신 DIM 수 : %d"), stn.CntLdtsDIM); lines.push_back(temp);
	temp.Format(_T(" - 관제통신 DOM 수 : %d"), stn.CntLdtsDOM); lines.push_back(temp);
	temp.Format(_T(" - 진로 수 : %d"), stn.NoOfRouteExt); lines.push_back(temp);
	temp.Format(_T(" - 궤도 수 : %d"), stn.NoOfTrack); lines.push_back(temp);
	temp.Format(_T(" - 신호기 수 : %d"), stn.NoOfSignal); lines.push_back(temp);
	temp.Format(_T(" - 선로전환기 수 : %d"), stn.NoOfSwitch); lines.push_back(temp);
	temp.Format(_T(" - 건널목 수 : %d"), stn.NoOfLevelCross); lines.push_back(temp);
	temp.Format(_T(" - 입력 카드 수 : %d"), stn.NoOfInCard); lines.push_back(temp);
	temp.Format(_T(" - 출력 카드 수 : %d"), stn.NoOfOutCard); lines.push_back(temp);
	temp.Format(_T(" - 선로전환기 카드 수 : %d"), stn.NoOfSdCard); lines.push_back(temp);
	temp.Format(_T(" - 폐색 제어 수 : %d"), stn.NoOfBlock); lines.push_back(temp);
	temp.Format(_T(" - 전차선 절연구간 수 : %d"), stn.NoOfDeadSection); lines.push_back(temp);
	temp.Format(_T(" - CPT 수 : %d"), stn.NoOfCpt); lines.push_back(temp);
	temp.Format(_T(" - 히터 수 : %d"), stn.NoOfHeat); lines.push_back(temp);
	temp.Format(_T(" - 연동논리부 정류기 수 : %d"), stn.AcrCntEis); lines.push_back(temp);
	temp.Format(_T(" - AF 정류기 수 : %d"), stn.AcrCntAF); lines.push_back(temp);

	// 5. 비상정지 정보 배열 파싱 (모든 인덱스 고정 순회)
	lines.push_back(_T("")); // 여백 줄 분리
	lines.push_back(_T("--- [비상정지 정보] ---"));
	for (int i = 0; i < MAX_EMG_STOP; ++i)
	{
		for (int dir = 0; dir < 2; ++dir)
		{
			CString dirStr = (dir == 0) ? _T("상선") : _T("하선");
			CString nameStr = GetSafeString(stn.EmgStop[i][dir].Name);
			nameStr.Trim();
			if (nameStr.IsEmpty()) nameStr = _T("(없음)");

			temp.Format(_T(" - 비상정지[%d][%s] 이름 : %s"), i, (LPCTSTR)dirStr, (LPCTSTR)nameStr);
			lines.push_back(temp);

			CString arrSigs = GetDBNameByArray(stn.EmgStop[i][dir].ArrSignal, SignalIdx);
			if (arrSigs.IsEmpty()) arrSigs = _T("---");
			temp.Format(_T("   > 장내 신호기 : %s"), (LPCTSTR)arrSigs);
			lines.push_back(temp);

			CString depSigs = GetDBNameByArray(stn.EmgStop[i][dir].DepSignal, SignalIdx);
			if (depSigs.IsEmpty()) depSigs = _T("---");
			temp.Format(_T("   > 출발 신호기 : %s"), (LPCTSTR)depSigs);
			lines.push_back(temp);

			CString ioStr = CommonUtil::GetIOName(stn.EmgStop[i][dir].Output);
			temp.Format(_T("   > 출력(IO) : %s"), (LPCTSTR)ioStr);
			lines.push_back(temp);
		}
	}

	// 6. I/O Position 데이터 파싱 (모든 슬롯 고정 출력)
	lines.push_back(_T("")); // 여백 줄 분리
	lines.push_back(_T("--- [I/O 및 제어 출력 정보] ---"));
	auto addAlwaysIO = [&](const IO_Position_t& io, const CString& label) {
		CString ioStr = CommonUtil::GetIOName(io);
		temp.Format(_T(" - %s : %s"), (LPCTSTR)label, (LPCTSTR)ioStr);
		lines.push_back(temp);
		};

	// 임시속도(Slow Order) 출력
	for (int i = 0; i < MAX_SPEED_CTRL; i++) {
		CString label; label.Format(_T("임시속도 출력[%d]"), i + 1);
		addAlwaysIO(stn.SpeedCtrl[i], label);
	}
	// 인접역 임시속도 출력
	for (int i = 0; i < MAX_SPEED_CTRL_NEAR; i++) {
		CString label; label.Format(_T("인접역 임시속도 출력[%d]"), i + 1);
		addAlwaysIO(stn.SpeedCtrlNear[i], label);
	}
	// 히터 / 전차선 출력
	for (int i = 0; i < 4; i++) {
		CString label; label.Format(_T("Switch Heater 출력[%d]"), i + 1);
		addAlwaysIO(stn.OutHeater[i], label);
	}
	for (int i = 0; i < 2; i++) {
		CString label; label.Format(_T("전차선 출력[%d]"), i + 1);
		addAlwaysIO(stn.OutEL[i], label);
	}

	// 모드 및 주계 출력
	addAlwaysIO(stn.OutCtc, _T("CTC 모드시 출력"));
	addAlwaysIO(stn.OutLocal, _T("Local 모드시 출력"));
	addAlwaysIO(stn.OutMain[0], _T("주계출력 [1계]"));
	addAlwaysIO(stn.OutMain[1], _T("주계출력 [2계]"));

	return lines;
}

// bIsOrigin이 true이면 원본(Origin), false이면 비교군(Diff) 데이터에서 이름을 조회합니다.
std::vector<CString> DiffCompareFrame::ConvertTrackInfoText(const std::span<TrackInfoType>& trackList, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;

	// [이름 조회 람다] bIsOrigin 플래그에 맞춰 올바른 CommonUtil 함수를 호출합니다.
	auto GetDBName = [&](BYTE nNum, GetDBNameByNum num) -> CString {
		if (bIsOrigin) {
			return CommonUtil::GetOriginNameByNumber(nNum, num);
		}
		else {
			return CommonUtil::GetDiffNameByNumber(nNum, num);
		}
		};

	// [안전한 궤도 이름 조회 람다] (현재 순회 중인 궤도 리스트 기준)
	auto GetSafeTrackName = [&](BYTE trackIdx) -> CString {
		if (trackIdx == 0 || trackIdx == 0xFF || trackIdx >= trackList.size()) {
			return _T("-");
		}
		return GetSafeString(trackList[trackIdx].Name, 20);
		};

	// 전달받은 궤도 배열 전체를 순회합니다.
	for (const auto& track : trackList)
	{
		// 유효하지 않은(비어있는) 궤도는 건너뜁니다.
		if (track.Name[0] == 0 || track.Name[0] == 0xFF) continue;

		// 1. 기본 정보 (궤도 이름)
		lines.push_back(_T("========================================"));
		CString trackName = GetSafeString(track.Name, 20);
		temp.Format(_T("[궤도 이름] %s"), (LPCTSTR)trackName);
		lines.push_back(temp);
		lines.push_back(_T("----------------------------------------"));

		// 2. Kind.Value (궤도 종류 플래그)
		lines.push_back(_T("[궤도 종류]"));
		CString trackKindOpts = _T("");
		auto appendTrackKind = [&](bool bSet, LPCTSTR desc) {
			if (bSet) {
				if (!trackKindOpts.IsEmpty()) trackKindOpts += _T(", ");
				trackKindOpts += desc;
			}
			};

		appendTrackKind(IsBitSet(track.Kind.Value.ApproachT, 0), _T("접근쇄정 궤도 (ApproachT)"));
		appendTrackKind(IsBitSet(track.Kind.Value.DetectorT, 0), _T("보류쇄정 궤도 (DetectorT)"));
		appendTrackKind(IsBitSet(track.Kind.Value.MainT, 0), _T("본선 궤도 (MainT)"));
		appendTrackKind(IsBitSet(track.Kind.Value.BlockT, 0), _T("폐색 궤도 (BlockT)"));
		appendTrackKind(IsBitSet(track.Kind.Value.IncSignalT, 0), _T("신호기 포함 궤도 (IncSignalT)"));
		appendTrackKind(IsBitSet(track.Kind.Value.IncSwitchT, 0), _T("선로전환기 포함 궤도 (IncSwitchT)"));
		appendTrackKind(IsBitSet(track.Kind.Value.FirstT, 0), _T("구내 첫번째 궤도 / 접근벨 설정 (FirstT)"));
		appendTrackKind(IsBitSet(track.Kind.Value.LockT, 0), _T("폐로쇄정 구간 궤도 (LockT)"));
		appendTrackKind(IsBitSet(track.Kind.Value.CptTrack, 0), _T("CPT 궤도 (CptTrack)"));
		appendTrackKind(IsBitSet(track.Kind.Value.SideTrack, 0), _T("안전측선 또는 출구 (SideTrack bit0)"));
		appendTrackKind(IsBitSet(track.Kind.Value.SideTrack, 1), _T("궤도장애 없음 (SideTrack bit1)"));
		appendTrackKind(IsBitSet(track.Kind.Value.SideTrack, 2), _T("궤도 이상복구 없음 (SideTrack bit2)"));
		appendTrackKind(IsBitSet(track.Kind.Value.SpcTrack, 0), _T("타역 궤도 (SpcTrack)"));
		appendTrackKind(IsBitSet(track.Kind.Value.VirtualTrk, 0), _T("가상궤도 (VirtualTrk bit0)"));
		appendTrackKind(IsBitSet(track.Kind.Value.VirtualTrk, 1), _T("궤도점유로 진로 제어불가 설정 없음 (VirtualTrk bit1)"));

		if (trackKindOpts.IsEmpty()) {
			trackKindOpts = _T("없음");
		}

		CString finalTrackKindLine;
		finalTrackKindLine.Format(_T("  - %s"), (LPCTSTR)trackKindOpts);
		lines.push_back(finalTrackKindLine);

		// 3. AppTime (복구 시소시간)
		lines.push_back(_T("[궤도복구 시소시간]"));
		BYTE appTimeVal = track.AppTime.Value.AppTime;
		CString timeStr = _T("2000 ms (default)");
		if (IsBitSet(appTimeVal, 0)) timeStr = _T("0 초 - 사용하지 않음");
		else if (IsBitSet(appTimeVal, 1)) timeStr = _T("500 ms");
		else if (IsBitSet(appTimeVal, 2)) timeStr = _T("1000 ms");
		else if (IsBitSet(appTimeVal, 3)) timeStr = _T("1200 ms");
		else if (IsBitSet(appTimeVal, 4)) timeStr = _T("1500 ms");
		else if (IsBitSet(appTimeVal, 5)) timeStr = _T("1800 ms");
		else if (IsBitSet(appTimeVal, 6)) timeStr = _T("2500 ms");
		else if (IsBitSet(appTimeVal, 7)) timeStr = _T("3000 ms");
		temp.Format(_T("  - 시소시간: %s"), (LPCTSTR)timeStr);
		lines.push_back(temp);

		// 4. Equipment (장비 수)
		lines.push_back(_T("[설비 수량]"));
		temp.Format(_T("  - 선로전환기 수: %d, 신호기 수: %d"), track.Equipment.NoOfSwitch, track.Equipment.NoOfSignal);
		lines.push_back(temp);

		// 5. Switch 배열
		bool bHasSwitch = false;
		CString switchListStr = _T("");
		for (int i = 0; i < _countof(track.Switch); ++i)
		{
			BYTE swNo = track.Switch[i].SwitchNo;
			if (swNo != 0 && swNo != 0xFF)
			{
				CString swName = GetDBName(swNo, SwitchIdx); // 원본/비교군 자동 분기
				if (bHasSwitch) switchListStr += _T(", ");
				temp.Format(_T("%d(%s)"), swNo, (LPCTSTR)swName);
				switchListStr += temp;
				bHasSwitch = true;
			}
		}
		if (bHasSwitch)
		{
			lines.push_back(_T("[포함된 선로전환기]"));
			lines.push_back(_T("  - ") + switchListStr);
		}
		else {
			lines.push_back(_T("[포함된 선로전환기]"));
			lines.push_back(_T("  - 없음"));
		}

		// 6. 인접 궤도 및 연계 번호
		lines.push_back(_T("[인접 및 연계 번호]"));
		CString leftName = GetSafeTrackName(track.LeftTrack);
		CString rightName = GetSafeTrackName(track.RightTrack);
		temp.Format(_T("  - Left 궤도: %d (%s), Right 궤도: %d (%s)"), track.LeftTrack, (LPCTSTR)leftName, track.RightTrack, (LPCTSTR)rightName);
		lines.push_back(temp);

		CString incSignals = _T("");
		bool bHasIncSig = false;
		for (int i = 0; i < _countof(track.IncSignal); ++i)
		{
			BYTE sigNo = track.IncSignal[i];
			if (sigNo != 0 && sigNo != 0xFF)
			{
				CString sigName = GetDBName(sigNo, SignalIdx);
				if (bHasIncSig) incSignals += _T(", ");
				CString tmp;
				tmp.Format(_T("%s"), (LPCTSTR)sigName);
				incSignals += tmp;
				bHasIncSig = true;
			}
		}
		if (!incSignals.IsEmpty() && incSignals != _T("-"))
		{
			temp.Format(_T("  - 궤도 포함된 신호기: %s"), (LPCTSTR)incSignals);
			lines.push_back(temp);
		}
		else {
			lines.push_back(_T(" - 궤도 포함된 신호기 X"));
		}

		CString blockName = GetDBName(track.InBlockNo, BlockIdx);
		CString cptName = GetDBName(track.CptNo, CPTIdx);
		temp.Format(_T("  - 관련 폐색표시: %d (%s)"), track.InBlockNo, (LPCTSTR)blockName);
		lines.push_back(temp);
		temp.Format(_T("  - 관련 CPT 번호: %d (%s)"), track.CptNo, (LPCTSTR)cptName);
		lines.push_back(temp);
		temp.Format(_T("  - 열번창 Table Index : %d"), track.TrnIdx);
		lines.push_back(temp);

		// 7. SpeedType
		lines.push_back(_T("[속도 제한 설정]"));
		if (IsBitSet(track.SpeedType, 0)) lines.push_back(_T("  - 25 Km/h"));
		if (IsBitSet(track.SpeedType, 1)) lines.push_back(_T("  - 40 km/h"));
		if (IsBitSet(track.SpeedType, 2)) lines.push_back(_T("  - 60 km/h"));
		if (IsBitSet(track.SpeedType, 3)) lines.push_back(_T("  - 70 km/h"));
		if (IsBitSet(track.SpeedType, 4)) lines.push_back(_T("  - 80 km/h"));
		if (IsBitSet(track.SpeedType, 5)) lines.push_back(_T("  - CAB 출력"));
		if (IsBitSet(track.SpeedType, 6)) lines.push_back(_T("  - YD"));
		if (IsBitSet(track.SpeedType, 7)) lines.push_back(_T("  - YC"));

		// 8. AutoRteNo 및 TrkLockSwitch
		temp.Format(_T("[자동진로 Index]: %d"), track.AutoRteNo);
		lines.push_back(temp);

		bool bHasLockSwitch = false;
		for (int i = 0; i < _countof(track.TrkLockSwitch); ++i)
		{
			const auto& lockSw = track.TrkLockSwitch[i];
			if (lockSw.SwitchNo != 0 && lockSw.SwitchNo != 0xFF)
			{
				if (!bHasLockSwitch)
				{
					lines.push_back(_T("[궤도점유시 쇄정 선로전환기]"));
					bHasLockSwitch = true;
				}

				CString swName = GetDBName(lockSw.SwitchNo, SwitchIdx);
				CString dirStr = _T("알 수 없음");
				if (lockSw.SwitchDir == 1) dirStr = _T("정위");
				else if (lockSw.SwitchDir == 2) dirStr = _T("반위");
				else if (lockSw.SwitchDir == 3) dirStr = _T("정위, 반위 모두");

				CString lockTimeStr;
				if (lockSw.LockTime == 255) lockTimeStr = _T("계속 쇄정 (255)");
				else lockTimeStr.Format(_T("%d 초"), lockSw.LockTime);

				temp.Format(_T("  - 선로전환기: %d (%s) | 방향: %s | 쇄정시간: %s | 진로번호(RteNo): %d"),
					lockSw.SwitchNo, (LPCTSTR)swName, (LPCTSTR)dirStr, (LPCTSTR)lockTimeStr, lockSw.RteNo);
				lines.push_back(temp);
			}
		}

		// 9. PlatForm
		lines.push_back(_T("[플랫폼 정보]"));
		temp.Format(_T("  - 플랫폼 번호: %d"), track.PlatForm.PlatFormNo);
		lines.push_back(temp);
		if (IsBitSet(track.PlatForm.Kind.Value.PlatForm, 0)) {
			lines.push_back(_T("  - 플랫폼 궤도: Yes"));
		}
		if (IsBitSet(track.PlatForm.Kind.Value.UpTrack, 0)) {
			lines.push_back(_T("  - 선로 구분: 하선궤도"));
		}
		else {
			lines.push_back(_T("  - 선로 구분: 상선궤도"));
		}

		// 궤도 데이터 간의 여백 추가
		lines.push_back(_T(""));
	}

	return lines;
}
void DiffCompareFrame::SetTrackInfo()
{
	auto& dc = DataComparison::GetInstance();

	std::vector<CString> leftLines;
	std::vector<CString> rightLines;

	const bool hasOrigin = dc.HasOriginal();
	const bool hasDiff = dc.HasDiff();

	// 1. 둘 다 데이터가 없으면 중단
	if (!hasOrigin && !hasDiff)
	{
		return;
	}

	// 2. 원본(Left) 데이터 수집 및 예외 처리
	if (hasOrigin)
	{
		auto originalTracks = dc.GetOriginalTrack();
		leftLines = ConvertTrackInfoText(originalTracks, true);
	}
	else
	{
		leftLines.push_back(_T("선택한 파일이 없습니다."));
	}

	// 3. 비교군(Right) 데이터 수집 및 예외 처리
	if (hasDiff)
	{
		auto diffTracks = dc.GetDiffTrack();
		rightLines = ConvertTrackInfoText(diffTracks, false);
	}
	else
	{
		rightLines.push_back(_T("비교할 파일이 없습니다."));
	}

	// 4. 수집된 라인을 전달하여 [Diff 정렬 -> 화면 출력 -> 색상 하이라이트] 일괄 처리
	ApplyDiffToUI(leftLines, rightLines);
}

void DiffCompareFrame::SetSignalInfo()
{
	auto& dc = DataComparison::GetInstance();

	std::vector<CString> leftLines;
	std::vector<CString> rightLines;

	const bool hasOrigin = dc.HasOriginal();
	const bool hasDiff = dc.HasDiff();

	// 1. 둘 다 데이터가 없으면 중단
	if (!hasOrigin && !hasDiff)
	{
		return;
	}

	// 2. 원본(Left) 데이터 수집 및 예외 처리
	if (hasOrigin)
	{
		auto originalSignals = dc.GetOriginalSignal();
		leftLines = ConvertSignalInfoText(originalSignals, true);
	}
	else
	{
		leftLines.push_back(_T("선택한 파일이 없습니다."));
	}

	// 3. 비교군(Right) 데이터 수집 및 예외 처리
	if (hasDiff)
	{
		auto diffSignals = dc.GetDiffSignal();
		rightLines = ConvertSignalInfoText(diffSignals, false);
	}
	else
	{
		rightLines.push_back(_T("비교할 파일이 없습니다."));
	}

	// 4. 수집된 라인을 전달하여 [Diff 정렬 -> 화면 출력 -> 색상 하이라이트] 일괄 처리
	ApplyDiffToUI(leftLines, rightLines);
}
std::vector<CString> DiffCompareFrame::ConvertSignalInfoText(const std::span<SignalInfoType>& signalList, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;

	// 원본인지 비교군인지에 따라 CommonUtil 함수를 선택하는 람다
	auto GetDBName = [&](BYTE nNum, GetDBNameByNum num) -> CString {
		if (bIsOrigin) {
			return CommonUtil::GetOriginNameByNumber(nNum, num);
		}
		else {
			return CommonUtil::GetDiffNameByNumber(nNum, num);
		}
		};

	// 전달받은 신호기 배열 전체를 순회합니다.
	for (const auto& signal : signalList)
	{
		// 유효하지 않은(비어있는) 신호기는 건너뜁니다.
		if (signal.Name[0] == 0 || signal.Name[0] == 0xFF) continue;

		// 1. 기본 정보 (신호기 이름)
		lines.push_back(_T("========================================"));
		CString sigName = GetSafeString(signal.Name, 20);
		temp.Format(_T("[신호기 이름] %s"), (LPCTSTR)sigName);
		lines.push_back(temp);
		lines.push_back(_T("----------------------------------------"));

		// 2. 신호기 종류 (Kind.Value)
		lines.push_back(_T("[신호기 종류 (Kind.Value)]"));
		CString signalOptions = _T("");
		auto appendSignal = [&](bool bSet, LPCTSTR desc) {
			if (bSet) {
				if (!signalOptions.IsEmpty()) signalOptions += _T(", ");
				signalOptions += desc;
			}
			};

		appendSignal(IsBitSet(signal.Kind.Value.MainS, 0), _T("주신호기 (MainS)"));
		appendSignal(IsBitSet(signal.Kind.Value.ShuntD, 0), _T("입환 표지 (ShuntD)"));
		appendSignal(IsBitSet(signal.Kind.Value.ShuntS, 0), _T("입환 신호기 (ShuntS)"));
		appendSignal(IsBitSet(signal.Kind.Value.BlockS, 0), _T("폐색 신호기 (BlockS)"));
		appendSignal(IsBitSet(signal.Kind.Value.HomeBlockS, 0), _T("구내 폐색 신호기 (HomeBlockS)"));
		appendSignal(IsBitSet(signal.Kind.Value.CallOnS, 0), _T("유도등 포함 (CallOnS)"));
		appendSignal(IsBitSet(signal.Kind.Value.RepeatS, 0), _T("중계 신호기 (RepeatS)"));
		appendSignal(IsBitSet(signal.Kind.Value.IncRepeatS, 0), _T("중계 신호기 포함 (IncRepeatS)"));
		appendSignal(IsBitSet(signal.Kind.Value.UmhoSig, 0), _T("엄호신호기 (UmhoSig)"));
		appendSignal(IsBitSet(signal.Kind.Value.IsTTB, 0), _T("TTB 존재 (IsTTB)"));
		appendSignal(IsBitSet(signal.Kind.Value.CptSignal, 0), _T("CPT 신호기 (CptSignal)"));
		appendSignal(IsBitSet(signal.Kind.Value.SpcSignal, 0), _T("타역 신호기 (SpcSignal)"));

		if (signalOptions.IsEmpty()) {
			signalOptions = _T("없음");
		}

		CString finalSignalLine;
		finalSignalLine.Format(_T("  - %s"), (LPCTSTR)signalOptions);
		lines.push_back(finalSignalLine);
		// 3. 진로 및 현시 수
		lines.push_back(_T("[진로 및 현시 수]"));
		temp.Format(_T("  - 진로 수 (NoOfRoute): %d, 현시 수 (NoOfLight): %d"), signal.NoOfRoute, signal.NoOfLight);
		lines.push_back(temp);

		// 4. 관련 궤도 및 연계 신호기 번호 (CommonUtil 이름 자동 조회 적용)
		lines.push_back(_T("[관련 설비 및 번호]"));
		CString trackName = GetDBName(signal.TrackNo, TrackIdx);
		CString repeatSigName = GetDBName(signal.RepeatSigNo, SignalIdx);
		CString frontSigName = GetDBName(signal.FrontSignalNo, SignalIdx);

		temp.Format(_T("  - 신호기 궤도: %d (%s)"), signal.TrackNo, (LPCTSTR)trackName);
		lines.push_back(temp);
		temp.Format(_T("  - 중계 신호기 번호: %d (%s)"), signal.RepeatSigNo, (LPCTSTR)repeatSigName);
		lines.push_back(temp);
		temp.Format(_T("  - 전방 신호기 번호: %d (%s)"), signal.FrontSignalNo, (LPCTSTR)frontSigName);
		lines.push_back(temp);

		// 신호기 데이터 간 여백 추가
		lines.push_back(_T(""));
	}

	return lines;
}
void DiffCompareFrame::SetSwitchInfo()
{
	auto& dc = DataComparison::GetInstance();

	std::vector<CString> leftLines;
	std::vector<CString> rightLines;

	const bool hasOrigin = dc.HasOriginal();
	const bool hasDiff = dc.HasDiff();

	// 1. 둘 다 데이터가 없으면 중단
	if (!hasOrigin && !hasDiff)
	{
		return;
	}

	// 2. 원본(Left) 데이터 수집 및 예외 처리
	if (hasOrigin)
	{
		auto originalSwitches = dc.GetOriginalSwitch();
		leftLines = ConvertSwitchInfoText(originalSwitches, true);
	}
	else
	{
		leftLines.push_back(_T("선택한 파일이 없습니다."));
	}

	// 3. 비교군(Right) 데이터 수집 및 예외 처리
	if (hasDiff)
	{
		auto diffSwitches = dc.GetDiffSwitch();
		rightLines = ConvertSwitchInfoText(diffSwitches, false);
	}
	else
	{
		rightLines.push_back(_T("비교할 파일이 없습니다."));
	}

	// 4. 수집된 라인을 전달하여 [Diff 정렬 -> 화면 출력 -> 색상 하이라이트] 일괄 처리
	ApplyDiffToUI(leftLines, rightLines);
}
std::vector<CString> DiffCompareFrame::ConvertSwitchInfoText(const std::span<SwitchInfoType>& switchList, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;

	// 원본인지 비교군인지에 따라 CommonUtil 함수를 선택하는 람다
	auto GetDBName = [&](BYTE nNum, GetDBNameByNum num) -> CString {
		if (bIsOrigin) {
			return CommonUtil::GetOriginNameByNumber(nNum, num);
		}
		else {
			return CommonUtil::GetDiffNameByNumber(nNum, num);
		}
		};

	// 전달받은 선로전환기 배열 전체를 순회합니다.
	for (const auto& sw : switchList)
	{
		// 유효하지 않은(비어있는) 선로전환기는 건너뜁니다.
		if (sw.Name[0] == 0 || sw.Name[0] == 0xFF) continue;

		// 1. 기본 정보 (선로전환기 이름)
		lines.push_back(_T("========================================"));
		CString swName = GetSafeString(sw.Name, 20);
		temp.Format(_T("[선로전환기 이름] %s"), (LPCTSTR)swName);
		lines.push_back(temp);
		lines.push_back(_T("----------------------------------------"));

		// 2. 종류 (Kind.Value)
		lines.push_back(_T("[선로전환기 종류 (Kind.Value)]"));
		CString switchOptions = _T("");
		auto appendSwitch = [&](bool bSet, LPCTSTR desc) {
			if (bSet) {
				if (!switchOptions.IsEmpty()) switchOptions += _T(", ");
				switchOptions += desc;
			}
			};

		appendSwitch(IsBitSet(sw.Kind.Value.Single, 0), _T("단동 선로전환기 (Single)"));
		appendSwitch(IsBitSet(sw.Kind.Value.Double, 0), _T("쌍동 선로전환기 (Double)"));
		appendSwitch(IsBitSet(sw.Kind.Value.Triple, 0), _T("삼동 선로전환기 (Triple)"));
		appendSwitch(IsBitSet(sw.Kind.Value.FourTime, 0), _T("사동 선로전환기 (FourTime)"));
		appendSwitch(IsBitSet(sw.Kind.Value.Scissors, 0), _T("시서스 선로전환기 (Scissors)"));
		appendSwitch(IsBitSet(sw.Kind.Value.Nose, 0), _T("노스가동 선로전환기 (Nose)"));
		appendSwitch(IsBitSet(sw.Kind.Value.Twin, 0), _T("쌍동 표시분리 설정 (Twin)"));
		appendSwitch(IsBitSet(sw.Kind.Value.SpcSwitch, 0), _T("타역 선로전환기 (SpcSwitch)"));

		if (switchOptions.IsEmpty()) {
			switchOptions = _T("없음");
		}

		CString finalSwitchLine;
		finalSwitchLine.Format(_T("  - %s"), (LPCTSTR)switchOptions);
		lines.push_back(finalSwitchLine);
		// 3. 점 궤도 번호 (A, B, C, D 궤도)
		lines.push_back(_T("[관련 궤도 번호]"));
		CString aTrk = GetDBName(sw.ATrackNo, TrackIdx);
		CString bTrk = GetDBName(sw.BTrackNo, TrackIdx);
		CString cTrk = GetDBName(sw.CTrackNo, TrackIdx);
		CString dTrk = GetDBName(sw.DTrackNo, TrackIdx);

		if (sw.ATrackNo != 0 && sw.ATrackNo != 0xFF) {
			temp.Format(_T("  - A 점 궤도: %s"), (LPCTSTR)aTrk);
			lines.push_back(temp);
		}
		if (sw.BTrackNo != 0 && sw.BTrackNo != 0xFF) {
			temp.Format(_T("  - B 점 궤도: %s"), (LPCTSTR)bTrk);
			lines.push_back(temp);
		}
		if (sw.CTrackNo != 0 && sw.CTrackNo != 0xFF) {
			temp.Format(_T("  - C 점 궤도: %s"), (LPCTSTR)cTrk);
			lines.push_back(temp);
		}
		if (sw.DTrackNo != 0 && sw.DTrackNo != 0xFF) {
			temp.Format(_T("  - D 점 궤도: %s"), (LPCTSTR)dTrk);
			lines.push_back(temp);
		}

		// 4. LockTrack 배열 (시간쇄정시 점유궤도)
		CString lockTracks = _T("");
		bool bHasLockTrk = false;
		for (int i = 0; i < _countof(sw.LockTrack); ++i)
		{
			BYTE trkNo = sw.LockTrack[i];
			if (trkNo != 0 && trkNo != 0xFF)
			{
				CString trkName = GetDBName(trkNo, TrackIdx);
				if (bHasLockTrk) lockTracks += _T(", ");
				CString tmp;
				tmp.Format(_T("%d(%s)"), trkNo, (LPCTSTR)trkName);
				lockTracks += tmp;
				bHasLockTrk = true;
			}
		}
		if (!lockTracks.IsEmpty())
		{
			temp.Format(_T("  - 시간쇄정 점유궤도 (LockTrack): %s"), (LPCTSTR)lockTracks);
			lines.push_back(temp);
		}

		// 5. 자동정위 전환 (AutoSwitch) 정보
		if (sw.AutoSwitch.AutoSwhTm > 0 || IsBitSet(sw.AutoSwitch.Kind.Value.AutoNormalIn, 0) || IsBitSet(sw.AutoSwitch.Kind.Value.AutoNormalRte, 0))
		{
			lines.push_back(_T("[자동정위 전환 설정 (AutoSwitch)]"));
			temp.Format(_T("  - 전환 시간 (AutoSwhTm): %d 초"), sw.AutoSwitch.AutoSwhTm);
			lines.push_back(temp);
			if (IsBitSet(sw.AutoSwitch.Kind.Value.AutoNormalIn, 0))  lines.push_back(_T("  - 입력 ON 시 자동정위전환 (AutoNormalIn)"));
			if (IsBitSet(sw.AutoSwitch.Kind.Value.AutoNormalRte, 0)) lines.push_back(_T("  - 진로취급/해정 후 자동정위전환 (AutoNormalRte)"));
		}

		// 선로전환기 데이터 간 여백 추가
		lines.push_back(_T(""));
	}

	return lines;
}
void DiffCompareFrame::SetBlockInfo()
{
	auto& dc = DataComparison::GetInstance();

	std::vector<CString> leftLines;
	std::vector<CString> rightLines;

	const bool hasOrigin = dc.HasOriginal();
	const bool hasDiff = dc.HasDiff();

	// 1. 원본(Left) 데이터 수집 및 예외 처리
	if (hasOrigin)
	{
		auto originalBlocks = dc.GetOriginalBlock();
		leftLines = ConvertBlockInfoText(originalBlocks, true);
	}
	else
	{
		leftLines.push_back(_T("선택한 파일이 없습니다."));
	}

	// 2. 비교군(Right) 데이터 수집 및 예외 처리
	if (hasDiff)
	{
		auto diffBlocks = dc.GetDiffBlock();
		rightLines = ConvertBlockInfoText(diffBlocks, false);
	}
	else
	{
		rightLines.push_back(_T("비교할 파일이 없습니다."));
	}

	// 3. 둘 다 데이터가 없는 경우 처리 중단
	if (!hasOrigin && !hasDiff)
	{
		return;
	}

	// 4. 수집된 라인을 전달하여 [Diff 정렬 -> 화면 출력 -> 색상 하이라이트] 일괄 진행
	ApplyDiffToUI(leftLines, rightLines);
}
std::vector<CString> DiffCompareFrame::ConvertBlockInfoText(const std::span<BlockTagInfoType>& blockList, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;

	// 원본인지 비교군인지에 따라 CommonUtil 함수를 선택하는 람다
	auto GetDBName = [&](BYTE nNum, GetDBNameByNum num) -> CString {
		if (bIsOrigin) {
			return CommonUtil::GetOriginNameByNumber(nNum, num);
		}
		else {
			return CommonUtil::GetDiffNameByNumber(nNum, num);
		}
		};

	// 전달받은 폐색 배열 전체를 순회합니다.
	for (const auto& blk : blockList)
	{
		// 유효하지 않은(비어있는) 폐색은 건너뜁니다.
		if (blk.Name[0] == 0 || blk.Name[0] == 0xFF) continue;

		// 1. 기본 정보 (폐색 이름)
		lines.push_back(_T("========================================"));
		CString blkName = GetSafeString(blk.Name, 20);
		temp.Format(_T("[폐색 이름] %s"), (LPCTSTR)blkName);
		lines.push_back(temp);
		lines.push_back(_T("----------------------------------------"));

		lines.push_back(_T("[폐색 종류 및 옵션]"));

		// 비트가 켜져 있는(설정된) 경우에만 항목을 추가하는 헬퍼 람다
		CString kindOptions = _T("");
		auto appendKind = [&](bool bSet, LPCTSTR desc) {
			if (bSet) {
				if (!kindOptions.IsEmpty()) kindOptions += _T(", ");
				kindOptions += desc;
			}
			};
		appendKind(IsBitSet(blk.KindInfo.Value.ExpBlk, 0), _T("고속선 폐색"));
		appendKind(IsBitSet(blk.KindInfo.Value.MetroRev, 0), _T("서울교통 3,4호선 역방향 폐색"));
		appendKind(IsBitSet(blk.KindInfo.Value.JeonlaRev, 0), _T("전라선 양방향 폐색"));
		appendKind(IsBitSet(blk.KindInfo.Value.RevStartRed, 0), _T("역방향 출발시 폐색 적색 표시 및 출력"));
		appendKind(IsBitSet(blk.KindInfo.Value.RevStartRed, 1), _T("역방향 출발 폐색 적색 점멸 없음"));
		appendKind(IsBitSet(blk.KindInfo.Value.OutKind, 0), _T("BR, DR 모두 여자시 출발신호 진행"));
		appendKind(IsBitSet(blk.KindInfo.Value.OutKind, 1), _T("BR, DR 모두 여자시 출발신호 주의"));
		appendKind(IsBitSet(blk.KindInfo.Value.OutKind, 2), _T("폐색 YY 여자 또는 진로 착점궤도 여자시 출발신호 현시"));
		appendKind(IsBitSet(blk.KindInfo.Value.RevArrSig, 0), _T("양방향 폐색 관련 제어 제한"));
		appendKind(IsBitSet(blk.KindInfo.Value.RevArrSig, 1), _T("양방향 폐색 장내/출발 제어 제한"));

		// 설정된 옵션이 하나도 없을 경우의 처리
		if (kindOptions.IsEmpty()) {
			kindOptions = _T("없음");
		}
		CString finalLine;
		finalLine.Format(_T("  - %s"), (LPCTSTR)kindOptions);
		lines.push_back(finalLine);

		// 3. 폐색 구분 및 연계 번호
		lines.push_back(_T("[폐색 구분 및 관련 설비]"));


		CString dirStr = _T("없음");
		if (blk.DirKind == 1) dirStr = _T("장내");
		else if (blk.DirKind == 2) dirStr = _T("출발");
		temp.Format(_T("  - 폐색 구분 (DirKind): %d (%s)"), blk.DirKind, (LPCTSTR)dirStr);
		lines.push_back(temp);

		CString oppBlkName = GetDBName(blk.OppositeBlock, BlockIdx);
		CString rearBlkName = GetDBName(blk.RearBlock, BlockIdx);
		CString umhoSigName = GetDBName(blk.UmhoSignal, SignalIdx);
		CString arrSigName = GetDBName(blk.ArrivalSignal, SignalIdx);

		temp.Format(_T("  - 상대 폐색 (OppositeBlock): %d (%s)"), blk.OppositeBlock, (LPCTSTR)oppBlkName);
		lines.push_back(temp);
		temp.Format(_T("  - 양방향 폐색 번호 (RearBlock): %d (%s)"), blk.RearBlock, (LPCTSTR)rearBlkName);
		lines.push_back(temp);
		temp.Format(_T("  - 엄호신호기 번호 (UmhoSignal): %d (%s)"), blk.UmhoSignal, (LPCTSTR)umhoSigName);
		lines.push_back(temp);
		temp.Format(_T("  - 양방향 폐색 장내 신호기 (ArrivalSignal): %d (%s)"), blk.ArrivalSignal, (LPCTSTR)arrSigName);
		lines.push_back(temp);

		// 4. 장내/출발 관련 궤도 배열
		CString arrTracks = _T("");
		bool bHasArrTrk = false;
		for (int i = 0; i < _countof(blk.ArrTrack); ++i)
		{
			BYTE trkNo = blk.ArrTrack[i];
			if (trkNo != 0 && trkNo != 0xFF)
			{
				CString trkName = GetDBName(trkNo, TrackIdx);
				if (bHasArrTrk) arrTracks += _T(", ");
				CString tmp; tmp.Format(_T("%d(%s)"), trkNo, (LPCTSTR)trkName);
				arrTracks += tmp;
				bHasArrTrk = true;
			}
		}
		if (!arrTracks.IsEmpty())
		{
			temp.Format(_T("  - 장내 관련 궤도 (ArrTrack): %s"), (LPCTSTR)arrTracks);
			lines.push_back(temp);
		}

		CString depTracks = _T("");
		bool bHasDepTrk = false;
		for (int i = 0; i < _countof(blk.DepTrack); ++i)
		{
			BYTE trkNo = blk.DepTrack[i];
			if (trkNo != 0 && trkNo != 0xFF)
			{
				CString trkName = GetDBName(trkNo, TrackIdx);
				if (bHasDepTrk) depTracks += _T(", ");
				CString tmp; tmp.Format(_T("%d(%s)"), trkNo, (LPCTSTR)trkName);
				depTracks += tmp;
				bHasDepTrk = true;
			}
		}
		if (!depTracks.IsEmpty())
		{
			temp.Format(_T("  - 출발/개통 관련 궤도 (DepTrack): %s"), (LPCTSTR)depTracks);
			lines.push_back(temp);
		}

		CString arrFirstTrkName = GetDBName(blk.ArrFirstTrk, TrackIdx);
		CString depLastTrkName = GetDBName(blk.DepLastTrk, TrackIdx);
		temp.Format(_T("  - 역방향 장내진로 첫 궤도 (ArrFirstTrk): %d (%s)"), blk.ArrFirstTrk, (LPCTSTR)arrFirstTrkName);
		lines.push_back(temp);
		temp.Format(_T("  - 역방향 출발진로 착점궤도 (DepLastTrk): %d (%s)"), blk.DepLastTrk, (LPCTSTR)depLastTrkName);
		lines.push_back(temp);

		// 5. 타이머 설정 (OutputTm, DelayTm, CancelTm)
		lines.push_back(_T("[폐색 타이머 설정]"));
		temp.Format(_T("  - 출력 최대 시간 (OutputTm): %d ms"), blk.OutputTm);
		lines.push_back(temp);
		temp.Format(_T("  - 입력처리 대기시간 (DelayTm): %d ms"), blk.DelayTm);
		lines.push_back(temp);
		temp.Format(_T("  - 취소 출력 최대 시간 (CancelTm): %d ms"), blk.CancelTm);
		lines.push_back(temp);

		// 6. DepBlkRedTrk (출발폐색 적색 표시 궤도)
		CString redTracks = _T("");
		bool bHasRedTrk = false;
		for (int i = 0; i < _countof(blk.DepBlkRedTrk); ++i)
		{
			BYTE trkNo = blk.DepBlkRedTrk[i];
			if (trkNo != 0 && trkNo != 0xFF)
			{
				CString trkName = GetDBName(trkNo, TrackIdx);
				if (bHasRedTrk) redTracks += _T(", ");
				CString tmp; tmp.Format(_T("%d(%s)"), trkNo, (LPCTSTR)trkName);
				redTracks += tmp;
				bHasRedTrk = true;
			}
		}
		if (!redTracks.IsEmpty())
		{
			temp.Format(_T("  - 출발폐색 적색 표시 궤도 (DepBlkRedTrk): %s"), (LPCTSTR)redTracks);
			lines.push_back(temp);
		}

		// 폐색 데이터 간 여백 추가
		lines.push_back(_T(""));
	}

	return lines;
}
void DiffCompareFrame::SetAllFaultInfo()
{
	auto& dc = DataComparison::GetInstance();

	std::vector<CString> leftLines;
	std::vector<CString> rightLines;

	const bool hasOrigin = dc.HasOriginal();
	const bool hasDiff = dc.HasDiff();

	// 1. 둘 다 데이터가 없으면 중단
	if (!hasOrigin && !hasDiff)
	{
		return;
	}

	// 텍스트 배열을 순서대로 이어붙여주는 람다 헬퍼
	auto AppendLines = [](std::vector<CString>& dest, const std::vector<CString>& src) {
		if (!src.empty()) {
			dest.insert(dest.end(), src.begin(), src.end());
		}
		};

	// 2. 원본(Left) 데이터 일괄 수집 및 병합
	if (hasOrigin)
	{
		AppendLines(leftLines, ConvertLevelCrossInfoText(dc.GetOriginalLevelCross(), true));
		AppendLines(leftLines, ConvertLCInfoText(dc.GetOriginalLC(), true));
		AppendLines(leftLines, ConvertDeadSectionInfoText(dc.GetOriginalDeadSection(), true));
		AppendLines(leftLines, ConvertFallLockInfoText(dc.GetOriginalFallLock(), true));
		AppendLines(leftLines, ConvertSTLInfoText(dc.GetOriginalSTL(), true));
		AppendLines(leftLines, ConvertFaultInfoText(dc.GetOriginalFault(), true));
		AppendLines(leftLines, ConvertHeatInfoText(dc.GetOriginalHeat(), true));
	}
	else
	{
		leftLines.push_back(_T("선택한 파일이 없습니다."));
	}

	// 3. 비교군(Right) 데이터 일괄 수집 및 병합
	if (hasDiff)
	{
		AppendLines(rightLines, ConvertLevelCrossInfoText(dc.GetDiffLevelCross(), false));
		AppendLines(rightLines, ConvertLCInfoText(dc.GetDiffLC(), false));
		AppendLines(rightLines, ConvertDeadSectionInfoText(dc.GetDiffDeadSection(), false));
		AppendLines(rightLines, ConvertFallLockInfoText(dc.GetDiffFallLock(), false));
		AppendLines(rightLines, ConvertSTLInfoText(dc.GetDiffSTL(), false));
		AppendLines(rightLines, ConvertFaultInfoText(dc.GetDiffFault(), false));
		AppendLines(rightLines, ConvertHeatInfoText(dc.GetDiffHeat(), false));
	}
	else
	{
		rightLines.push_back(_T("비교할 파일이 없습니다."));
	}

	// 4. 수집된 전체 라인을 전달하여 [Diff 정렬 -> 화면 출력 -> 색상 하이라이트] 일괄 처리
	ApplyDiffToUI(leftLines, rightLines);
}
std::vector<CString> DiffCompareFrame::ConvertLevelCrossInfoText(const std::span<LevelCrossInfoType>& list, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;
	for (const auto& item : list)
	{
		if (item.Name[0] == 0 || item.Name[0] == 0xFF) continue;
		lines.push_back(_T("========================================"));
		CString name = GetSafeString(item.Name, 20);
		temp.Format(_T("[건널목 정보 이름] %s"), (LPCTSTR)name);
		lines.push_back(temp);
		lines.push_back(_T("----------------------------------------"));
		lines.push_back(_T(""));
	}
	return lines;
}

// 2. 절연구간 정보 텍스트 변환
std::vector<CString> DiffCompareFrame::ConvertDeadSectionInfoText(const std::span<DeadSectionInfoType>& list, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;
	for (const auto& item : list)
	{
		if (item.Name[0] == 0 || item.Name[0] == 0xFF) continue;
		lines.push_back(_T("========================================"));
		CString name = GetSafeString(item.Name, 20);
		temp.Format(_T("[절연구간 이름] %s"), (LPCTSTR)name);
		lines.push_back(temp);
		lines.push_back(_T("----------------------------------------"));

		CString typeStr = _T("알 수 없음");
		if (item.type == 0x01) typeStr = _T("1계");
		else if (item.type == 0x02) typeStr = _T("2계");
		else if (item.type == 0x04) typeStr = _T("운용 (Input 여자: 1계 주계, 낙하: 2계 주계)");

		temp.Format(_T("  - 타입: 0x%02X (%s), 운용 Index: %d"), item.type, (LPCTSTR)typeStr, item.Index);
		lines.push_back(temp);

		// [적용] 실제 IO_Position_t 필드 반영
		temp.Format(_T("  - Input: %s"), (LPCTSTR)GetSafeIOPosition(item.Input));
		lines.push_back(temp);
		lines.push_back(_T(""));
	}
	return lines;
}

// 3. 지장물 정보 텍스트 변환
std::vector<CString> DiffCompareFrame::ConvertFallLockInfoText(const std::span<FallLockInfoType>& list, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;
	for (const auto& item : list)
	{
		if (item.Name[0] == 0 || item.Name[0] == 0xFF) continue;
		lines.push_back(_T("========================================"));
		CString name = GetSafeString(item.Name, 20);
		temp.Format(_T("[지장물 이름] %s"), (LPCTSTR)name);
		lines.push_back(temp);
		lines.push_back(_T("----------------------------------------"));

		CString typeStr = _T("알 수 없음");
		if (item.type == 1) typeStr = _T("낙석");
		else if (item.type == 2) typeStr = _T("보호");

		temp.Format(_T("  - 타입: %d (%s)"), item.type, (LPCTSTR)typeStr);
		lines.push_back(temp);

		// [적용] 실제 IO_Position_t 필드 반영
		temp.Format(_T("  - Input: %s"), (LPCTSTR)GetSafeIOPosition(item.Input));
		lines.push_back(temp);
		lines.push_back(_T(""));
	}
	return lines;
}

// 4. 출발반응등 정보 텍스트 변환
std::vector<CString> DiffCompareFrame::ConvertSTLInfoText(const std::span<STLInfoType>& list, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;
	for (const auto& item : list)
	{
		if (item.Name[0] == 0 || item.Name[0] == 0xFF) continue;
		lines.push_back(_T("========================================"));
		CString name = GetSafeString(item.Name, 20);
		temp.Format(_T("[출발반응등 이름] %s"), (LPCTSTR)name);
		lines.push_back(temp);
		lines.push_back(_T("----------------------------------------"));

		// [적용] 실제 IO_Position_t 필드 반영
		temp.Format(_T("  - InputStl: %s"), (LPCTSTR)GetSafeIOPosition(item.InputStl));
		lines.push_back(temp);
		temp.Format(_T("  - OutputStl: %s"), (LPCTSTR)GetSafeIOPosition(item.OutputStl));
		lines.push_back(temp);
		lines.push_back(_T(""));
	}
	return lines;
}

// 5. 기타 고장 정보 텍스트 변환
std::vector<CString> DiffCompareFrame::ConvertFaultInfoText(const std::span<FaultInfoType>& list, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;
	for (const auto& item : list)
	{
		if (item.Name[0] == 0 || item.Name[0] == 0xFF) continue;
		lines.push_back(_T("========================================"));
		CString name = GetSafeString(item.Name, 20);
		temp.Format(_T("[기타 고장 정보 이름] %s"), (LPCTSTR)name);
		lines.push_back(temp);
		lines.push_back(_T("----------------------------------------"));

		CString typeStr = (item.Type == 1) ? _T("출발대용표시등") : _T("기타");
		temp.Format(_T("  - 타입: %d (%s), 화면 숨김(Hide): %d"), item.Type, (LPCTSTR)typeStr, item.Hide);
		lines.push_back(temp);

		// [적용] 실제 IO_Position_t 필드 반영
		temp.Format(_T("  - InputFault: %s"), (LPCTSTR)GetSafeIOPosition(item.InputFault));
		lines.push_back(temp);
		lines.push_back(_T(""));
	}
	return lines;
}

// 6. 히터 정보 텍스트 변환
std::vector<CString> DiffCompareFrame::ConvertHeatInfoText(const std::span<HeatInfoType>& list, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;
	for (const auto& item : list)
	{
		if (item.szHeatName[0] == 0 || item.szHeatName[0] == 0xFF) continue;
		lines.push_back(_T("========================================"));
		CString heatName = GetSafeString(item.szHeatName, 10);
		temp.Format(_T("[Heater 이름] %s"), (LPCTSTR)heatName);
		lines.push_back(temp);
		lines.push_back(_T("----------------------------------------"));

		lines.push_back(_T("  [장애 알람 메시지 목록]"));
		for (int i = 0; i < _countof(item.AlmData); ++i)
		{
			CString almMsg = GetSafeString(item.AlmData[i].szAlmMsg, 20);
			if (!almMsg.IsEmpty() && almMsg != _T("-"))
			{
				temp.Format(_T("    - [%d] %s"), i, (LPCTSTR)almMsg);
				lines.push_back(temp);
			}
		}
		//lines.push_back(_T(""));
	}
	return lines;
}


void DiffCompareFrame::SetInterLock()
{
	auto& dc = DataComparison::GetInstance();

	std::vector<CString> leftLines;
	std::vector<CString> rightLines;

	const bool hasOrigin = dc.HasOriginal();
	const bool hasDiff = dc.HasDiff();

	// 1. 둘 다 데이터가 없으면 중단
	if (!hasOrigin && !hasDiff)
	{
		return;
	}

	// 2. 원본(Left) 데이터 수집 및 예외 처리
	if (hasOrigin)
	{
		auto InterLockInfo = dc.GetOriginalInterLock();
		auto RouteInfo = dc.GetOriginalRoute();
		leftLines = ConvertInterlockInfoText(InterLockInfo, RouteInfo, true);
	}
	else
	{
		leftLines.push_back(_T("선택한 파일이 없습니다."));
	}

	// 3. 비교군(Right) 데이터 수집 및 예외 처리
	if (hasDiff)
	{
		auto DiffCPTInfo = dc.GetDiffInterLock();
		auto DiffRouteInfo = dc.GetDiffRoute();
		rightLines = ConvertInterlockInfoText(DiffCPTInfo, DiffRouteInfo, false);
	}
	else
	{
		rightLines.push_back(_T("비교할 파일이 없습니다."));
	}

	// 4. 수집된 라인을 전달하여 [Diff 정렬 -> 화면 출력 -> 색상 하이라이트] 일괄 처리
	ApplyDiffToUI(leftLines, rightLines);
}
std::vector<CString> DiffCompareFrame::ConvertInterlockInfoText(const std::span<InterLockInfoType>& interLockList, const std::span<RouteInfoType>& routeList, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;

	// 원본인지 비교군인지에 따라 CommonUtil 함수를 선택하는 람다
	auto GetDBName = [&](BYTE nNum, GetDBNameByNum num) -> CString {
		if (bIsOrigin) {
			return CommonUtil::GetOriginNameByNumber(nNum, num);
		}
		else {
			return CommonUtil::GetDiffNameByNumber(nNum, num);
		}
		};

	for (size_t nIdx = 0; nIdx < interLockList.size(); ++nIdx)
	{
		const auto& item = interLockList[nIdx];
		if (item.Name[0] == 0 || (unsigned char)item.Name[0] == 0xFF) continue;

		UINT nRteNo = static_cast<UINT>(nIdx + 1);
		CString routeName = GetSafeString(item.Name, 20);
		routeName.Trim();

		// 1. 블록 헤더 (LCS 매칭의 고유 키)
		lines.push_back(_T("========================================"));
		temp.Format(_T("[연동진로 이름] %s"), (LPCTSTR)routeName);
		lines.push_back(temp);
		lines.push_back(_T("------------------------------------------------"));

		// 2. 진로 기본 정보 (신호기, 출발, 도착, 유도등)
		CString strSignalName = GetDBName(static_cast<BYTE>(item.RouteInfo.SignalNo), GetDBNameByNum::SignalIdx);
		CString strDepTrack = GetDBName(static_cast<BYTE>(item.RouteInfo.DepartureT), GetDBNameByNum::TrackIdx);
		CString strArrTrack = GetDBName(static_cast<BYTE>(item.RouteInfo.ArrivalT), GetDBNameByNum::TrackIdx);

		temp.Format(_T("  - 진로 기본: 신호기:%s, 출발:%s, 도착:%s"), (LPCTSTR)strSignalName, (LPCTSTR)strDepTrack, (LPCTSTR)strArrTrack);
		if (IsBitSet(item.RouteInfo.IsCallOnSig, 0)) {
			temp += _T(" [(무)유도등 ON]");
		}
		lines.push_back(temp);

		// 3. 대항진로 정보 (routeList 활용)
		int nRouteIdx = static_cast<int>(nRteNo) - 1;
		if (nRouteIdx >= 0 && nRouteIdx < static_cast<int>(routeList.size()))
		{
			const auto& rteItem = routeList[nRouteIdx];
			CString strOppList = _T("");
			bool bFirstOpp = true;

			for (int nIdxInc = 0; nIdxInc < MAX_INHIBIT_ROUTE; nIdxInc++)
			{
				WORD inhibitRteNo = rteItem.InhibitRteNo[nIdxInc];
				if (0 == inhibitRteNo) break;

				if (inhibitRteNo < interLockList.size()) {
					if (!bFirstOpp) strOppList += _T(", ");
					CString szEquipTmp = GetSafeString(interLockList[inhibitRteNo].Name, 20);
					strOppList += szEquipTmp;
					bFirstOpp = false;
				}
			}
			if (!strOppList.IsEmpty()) {
				temp.Format(_T("  - 대항진로: %s"), (LPCTSTR)strOppList);
				lines.push_back(temp);
			}

			// 4. 진로 구분 및 플래그
			const auto& kindVal = rteItem.Kind.Value;
			const auto& flagVal = rteItem.RouteFlag.Value;
			CString strRouteKind = _T("  - 진로구분:");
			if (IsBitSet(kindVal.Direction, 0)) strRouteKind += _T(" [Left방향]");
			else strRouteKind += _T(" [Right방향]");
			if (IsBitSet(kindVal.Special, 0)) strRouteKind += _T(" [유효장]");
			if (IsBitSet(kindVal.Special, 1)) strRouteKind += _T(" [단조건]");
			if (IsBitSet(kindVal.IsTTB, 0))    strRouteKind += _T(" [TTB]");
			if (IsBitSet(kindVal.IsBlock, 0))  strRouteKind += _T(" [구내폐색]");
			if (IsBitSet(kindVal.Arrive, 0))   strRouteKind += _T(" [장내]");
			if (IsBitSet(kindVal.Depart, 0))   strRouteKind += _T(" [출발]");
			if (IsBitSet(kindVal.Shunt, 0))    strRouteKind += _T(" [입환]");
			if (IsBitSet(kindVal.IsLC, 0))     strRouteKind += _T(" [건널목포함]");
			if (IsBitSet(flagVal.UdoSig, 0))   strRouteKind += _T(" [(무)유도진로]");
			lines.push_back(strRouteKind);

			// 5. 현시 정보 (Max / Min)
			LPCTSTR pszMaxAspect = _T("-------");
			switch (rteItem.MaxSignal & 0x0F) {
			case SIGNAL_PROCEED: pszMaxAspect = _T("진행-G"); break;
			case SIGNAL_CAUTION: pszMaxAspect = _T("주의-Y"); break;
			case SIGNAL_SLOW:    pszMaxAspect = _T("감속-YG"); break;
			case SIGNAL_BOUND:   pszMaxAspect = _T("경계-YY"); break;
			case SIGNAL_STOP:    pszMaxAspect = _T("정지"); break;
			}
			LPCTSTR pszMinAspect = _T("-------");
			switch (rteItem.MinSignal & 0x0F) {
			case SIGNAL_PROCEED: pszMinAspect = _T("진행-G"); break;
			case SIGNAL_CAUTION: pszMinAspect = _T("주의-Y"); break;
			case SIGNAL_SLOW:    pszMinAspect = _T("감속-YG"); break;
			case SIGNAL_BOUND:   pszMinAspect = _T("경계-YY"); break;
			case SIGNAL_STOP:    pszMinAspect = _T("정지"); break;
			}
			temp.Format(_T("  - 현시: Max:%02x(%s), Min:%02x(%s)"), (rteItem.MaxSignal & 0x0F), pszMaxAspect, (rteItem.MinSignal & 0x0F), pszMinAspect);
			lines.push_back(temp);

			// 전방 / 후방 신호기
			if (rteItem.FrontSignalNo > 0 || rteItem.RearSignalNo > 0) {
				CString strFront = rteItem.FrontSignalNo > 0 ? GetDBName(rteItem.FrontSignalNo, SignalIdx) : (CString)_T("-");
				CString strRear = rteItem.RearSignalNo > 0 ? GetDBName(rteItem.RearSignalNo, SignalIdx) : (CString)_T("-");
				temp.Format(_T("  - 전/후방 신호기: 전방[%s], 후방[%s]"), (LPCTSTR)strFront, (LPCTSTR)strRear);
				lines.push_back(temp);
			}
		}

		// 6. 카운트 / 수량 정보
		temp.Format(_T("  - 카운트: 선로전환기:%d, 단조건:%d, 신호기:%d, 궤도:%d, 진로쇄정:%d, 접근쇄정:%d"),
			item.Count.NoOfSwhLock, item.Count.NoOfExcept, item.Count.NoOfSigLock,
			item.Count.NoOfCtlLock, item.Count.NoOfRteLock, item.Count.NoOfAppLock);
		lines.push_back(temp);

		// 7. 쇄정 선로전환기 정보
		if (item.Count.NoOfSwhLock > 0) {
			CString strSwhLock = _T("");
			for (int i = 0; i < item.Count.NoOfSwhLock; i++) {
				if (item.SwitchLock[i].SwitchNo == 0) continue;
				CString strSwhName = GetDBName(static_cast<BYTE>(item.SwitchLock[i].SwitchNo), SwitchIdx);
				CString sub;
				sub.Format(_T(" %s[%d]"), (LPCTSTR)strSwhName, item.SwitchLock[i].Direction);
				strSwhLock += sub;
			}
			if (!strSwhLock.IsEmpty()) {
				temp.Format(_T("  - 쇄정 선로전환기:%s"), (LPCTSTR)strSwhLock);
				lines.push_back(temp);
			}
		}

		// 8. 진로쇄정 궤도 정보
		CString strRteTrk = _T("");
		for (int i = 0; i < NO_OF_LOCK_TRK; i++) {
			BYTE trkNo = item.ControlTrack[i];
			if (trkNo == 0) break;
			CString strTrkName = GetDBName(trkNo, TrackIdx);
			CString sub; sub.Format(_T(" %s"), (LPCTSTR)strTrkName);
			strRteTrk += sub;
		}
		if (!strRteTrk.IsEmpty()) {
			temp.Format(_T("  - 쇄정 궤도(ControlTrack):%s"), (LPCTSTR)strRteTrk);
			lines.push_back(temp);
		}

		// 항목 간 여백 추가 (다른 컨버터블록들과 동일한 규격)
		lines.push_back(_T(""));
	}

	return lines;
}
void DiffCompareFrame::SetCPTInfo()
{
	auto& dc = DataComparison::GetInstance();

	std::vector<CString> leftLines;
	std::vector<CString> rightLines;

	const bool hasOrigin = dc.HasOriginal();
	const bool hasDiff = dc.HasDiff();

	// 1. 둘 다 데이터가 없으면 중단
	if (!hasOrigin && !hasDiff)
	{
		return;
	}

	// 2. 원본(Left) 데이터 수집 및 예외 처리
	if (hasOrigin)
	{
		auto CPTInfo = dc.GetOriginalCPT();
		leftLines = ConvertCPTInfoText(CPTInfo, true);
	}
	else
	{
		leftLines.push_back(_T("선택한 파일이 없습니다."));
	}

	// 3. 비교군(Right) 데이터 수집 및 예외 처리
	if (hasDiff)
	{
		auto DiffCPTInfo = dc.GetDiffCPT();
		rightLines = ConvertCPTInfoText(DiffCPTInfo, false);
	}
	else
	{
		rightLines.push_back(_T("비교할 파일이 없습니다."));
	}

	// 4. 수집된 라인을 전달하여 [Diff 정렬 -> 화면 출력 -> 색상 하이라이트] 일괄 처리
	ApplyDiffToUI(leftLines, rightLines);
}

void DiffCompareFrame::SetDWELLInfo()
{
	auto& dc = DataComparison::GetInstance();

	std::vector<CString> leftLines;
	std::vector<CString> rightLines;

	const bool hasOrigin = dc.HasOriginal();
	const bool hasDiff = dc.HasDiff();

	// 1. 둘 다 데이터가 없으면 중단
	if (!hasOrigin && !hasDiff)
	{
		return;
	}

	// 2. 원본(Left) 데이터 수집 및 예외 처리
	if (hasOrigin)
	{
		auto dwellInfo = dc.GetOriginalDWELL();
		leftLines = ConvertDwellInfoText(dwellInfo, true);
	}
	else
	{
		leftLines.push_back(_T("선택한 파일이 없습니다."));
	}

	// 3. 비교군(Right) 데이터 수집 및 예외 처리
	if (hasDiff)
	{
		auto diffDwellInfo = dc.GetDiffDWELL();
		rightLines = ConvertDwellInfoText(diffDwellInfo, false);
	}
	else
	{
		rightLines.push_back(_T("비교할 파일이 없습니다."));
	}

	// 4. 수집된 라인을 전달하여 [Diff 정렬 -> 화면 출력 -> 색상 하이라이트] 일괄 처리
	ApplyDiffToUI(leftLines, rightLines);
}

std::vector<CString> DiffCompareFrame::ConvertCPTInfoText(const std::span<CPTInfoType>& list, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;

	auto GetDBName = [&](BYTE nNum, GetDBNameByNum num) -> CString {
		if (bIsOrigin) return CommonUtil::GetOriginNameByNumber(nNum, num);
		else return CommonUtil::GetDiffNameByNumber(nNum, num);
		};

	for (const auto& item : list)
	{
		if (item.CptName[0] == 0 || (unsigned char)item.CptName[0] == 0xFF) continue;

		lines.push_back(_T("========================================"));
		// char 배열이므로 명시적으로 CString 변환
		CString cptName = CString(item.CptName, 20).Trim();
		temp.Format(_T("[CPT 정보] 이름: %s (CPT 번호: %d)"), (LPCTSTR)cptName, item.CptNo);
		lines.push_back(temp);
		lines.push_back(_T("----------------------------------------"));

		CString kindStr = _T("알 수 없음");
		if (item.CptKind == 0x01) kindStr = _T("출발용 (신호기 점멸 표시)");
		else if (item.CptKind == 0x02) kindStr = _T("장내용 (궤도 점유 표시)");

		temp.Format(_T("  - 타입: 0x%02X (%s)"), item.CptKind, (LPCTSTR)kindStr);
		lines.push_back(temp);

		temp.Format(_T("  - 입력 위치 (CptInput): %s"), (LPCTSTR)GetSafeIOPosition(item.CptInput));
		lines.push_back(temp);

		lines.push_back(_T("  - CPT 연관 정보 목록 (신호기 / 궤도):"));
		bool bHasSub = false;
		for (int i = 0; i < 20; ++i)
		{
			const auto& sub = item.CptInfo[i];
			if (sub.SignalNo != 0 || sub.TrackNo != 0)
			{
				CString sigName = (sub.SignalNo != 0) ? GetDBName(sub.SignalNo, SignalIdx) : CString(_T("-"));
				CString trkName = (sub.TrackNo != 0) ? GetDBName(sub.TrackNo, TrackIdx) : CString(_T("-"));
				temp.Format(_T("    * [%d] 신호기: %d (%s) / 궤도: %d (%s)"),
					i, sub.SignalNo, (LPCTSTR)sigName, sub.TrackNo, (LPCTSTR)trkName);
				lines.push_back(temp);
				bHasSub = true;
			}
		}
		if (!bHasSub) {
			lines.push_back(_T("    * 등록된 연관 정보 없음"));
		}

		lines.push_back(_T(""));
	}

	return lines;
}

std::vector<CString> DiffCompareFrame::ConvertDwellInfoText(const std::span<DwellInfoType>& list, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;

	auto GetDBName = [&](BYTE nNum, GetDBNameByNum num) -> CString {
		if (bIsOrigin) return CommonUtil::GetOriginNameByNumber(nNum, num);
		else return CommonUtil::GetDiffNameByNumber(nNum, num);
		};

	for (const auto& item : list)
	{
		if (item.SubStnName[0] == 0 || item.SubStnName[0] == 0xFF) continue;

		lines.push_back(_T("========================================"));
		CString subStnName = GetSafeString(item.SubStnName, 20);
		temp.Format(_T("[소속역(Dwell) 정보] 역 이름: %s (역 번호: %d, 플랫폼 번호: %d)"),
			(LPCTSTR)subStnName, item.SubStnNo, item.PlatFormNo);
		lines.push_back(temp);
		lines.push_back(_T("------------------------------------------------"));

		// 역 상세 설정 값
		CString endStationStr = (item.SubStnInfo.Value.EndStation == 0x01) ? _T("종착역 (Dwell Lamp 없음)") : _T("일반역");
		CString upKindStr = (item.SubStnInfo.Value.UpKind == 0x01) ? _T("하선") : _T("상선");
		temp.Format(_T("  - 종착역 구분: %s, 선로 방향: %s"), (LPCTSTR)endStationStr, (LPCTSTR)upKindStr);
		lines.push_back(temp);

		// 플랫폼 궤도 인덱스 목록
		CString trkListStr;
		for (int i = 0; i < 4; ++i)
		{
			if (item.PlatFormTrk[i] != 0)
			{
				CString trkName = GetDBName(item.PlatFormTrk[i], TrackIdx);
				CString sub;
				sub.Format(_T("[%d: %s] "), item.PlatFormTrk[i], (LPCTSTR)trkName);
				trkListStr += sub;
			}
		}
		if (trkListStr.IsEmpty()) trkListStr = _T("-");
		temp.Format(_T("  - 플랫폼 궤도: %s"), (LPCTSTR)trkListStr);
		lines.push_back(temp);

		// 플랫폼 정차등 신호기 및 출발 신호기
		CString pfSigName = (item.PlatFormSig != 0) ? GetDBName(item.PlatFormSig, SignalIdx) : CString(_T("-"));
		CString depSigName = (item.DepSignal != 0) ? GetDBName(item.DepSignal, SignalIdx) : CString(_T("-"));
		temp.Format(_T("  - 정차등 현시체크 신호기: %d (%s)"), item.PlatFormSig, (LPCTSTR)pfSigName);
		lines.push_back(temp);
		temp.Format(_T("  - 출발 신호기: %d (%s)"), item.DepSignal, (LPCTSTR)depSigName);
		lines.push_back(temp);
		temp.Format(_T("  - 열차번호 창 인덱스: %d"), item.TrainInfoNo);
		lines.push_back(temp);

		// 비상정지 설정 궤도 목록
		CString emgListStr;
		for (int i = 0; i < 5; ++i)
		{
			if (item.EmgTrack[i] != 0)
			{
				CString trkName = GetDBName(item.EmgTrack[i], TrackIdx);
				CString sub;
				sub.Format(_T("[%d: %s] "), item.EmgTrack[i], (LPCTSTR)trkName);
				emgListStr += sub;
			}
		}
		if (emgListStr.IsEmpty()) emgListStr = _T("-");
		temp.Format(_T("  - 비상정지 설정 궤도: %s"), (LPCTSTR)emgListStr);
		lines.push_back(temp);

		lines.push_back(_T(""));
	}

	return lines;
}

std::vector<CString> DiffCompareFrame::ConvertLCInfoText(const std::span<LC_INFO_TYPE>& list, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;

	for (const auto& item : list)
	{
		// 유효하지 않은 데이터 건너뛰기
		if (item.Name1[0] == 0 || item.Name1[0] == 0xFF) continue;

		lines.push_back(_T("========================================"));

		CString name1 = GetSafeString(item.Name1, 10);
		CString name2 = GetSafeString(item.Name2, 4);

		// Name1과 Name2 조합 및 LC 번호 출력
		if (!name2.IsEmpty() && name2 != _T("-") && name2 != _T("\0"))
		{
			temp.Format(_T("[LC 정보] %s %s (LC 번호: %d)"), (LPCTSTR)name1, (LPCTSTR)name2, item.LcNo);
		}
		else
		{
			temp.Format(_T("[LC 정보] %s (LC 번호: %d)"), (LPCTSTR)name1, item.LcNo);
		}
		lines.push_back(temp);
		lines.push_back(_T("----------------------------------------"));

		// 입력 및 출력 I/O Position 정보 출력 (앞서 만든 GetSafeIOPosition 활용)
		temp.Format(_T("  - 입력 (LC_Inp): %s"), (LPCTSTR)GetSafeIOPosition(item.LC_Inp));
		lines.push_back(temp);

		temp.Format(_T("  - 출력 (LC_Out): %s"), (LPCTSTR)GetSafeIOPosition(item.LC_Out));
		lines.push_back(temp);

		// Status 비트 상태 분석
		lines.push_back(_T("  - 상태 설정 (Status):"));

		if (IsBitSet(item.Status, 0))
			lines.push_back(_T("    * Bit0=1 : 출력여자일 때 입력낙하"));
		else
			lines.push_back(_T("    * Bit0=0 : 출력여자일 때 입력여자"));

		if (IsBitSet(item.Status, 1))
			lines.push_back(_T("    * Bit1=1 : 부정입력 없음"));

		if (IsBitSet(item.Status, 3))
			lines.push_back(_T("    * Bit3=1 : 동작불능 없음"));

		if (IsBitSet(item.Status, 7))
			lines.push_back(_T("    * Bit7=1 : 평상시 OFF (동작시 ON)"));
		else
			lines.push_back(_T("    * Bit7=0 : 평상시 ON (동작시 OFF)"));

		// 데이터 간 여백
		lines.push_back(_T(""));
	}

	return lines;
}
void DiffCompareFrame::SetAllIOCardInfo()
{
	auto& dc = DataComparison::GetInstance();

	std::vector<CString> leftLines;
	std::vector<CString> rightLines;

	// 여러 데이터를 하나의 배열로 이어 붙여주는 람다 함수 (유용하게 재사용 가능)
	auto AppendLines = [](std::vector<CString>& dest, const std::vector<CString>& src) {
		if (!src.empty()) {
			dest.insert(dest.end(), src.begin(), src.end());
		}
		};

	// 1. 원본(Left) 데이터 모으기
	if (dc.HasOriginal())
	{
		AppendLines(leftLines, ConvertInputDataInfoText(dc.GetOriginalInput(), true));
		AppendLines(leftLines, ConvertIoCardAddressInfoText(dc.GetOriginalCardAddr(), true));
	}

	// 2. 비교군(Right) 데이터 모으기
	if (dc.HasDiff())
	{
		AppendLines(rightLines, ConvertInputDataInfoText(dc.GetDiffInput(), false));
		AppendLines(rightLines, ConvertIoCardAddressInfoText(dc.GetDiffCardAddr(), false));
	}

	// 3. 모은 데이터를 "비교 + 표시 + 하이라이트" 공통 함수로 전달
	ApplyDiffToUI(leftLines, rightLines);
}
std::vector<CString> DiffCompareFrame::ConvertInputDataInfoText(const InputDataType& inputData, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;

	auto GetDBName = [&](BYTE nNum, GetDBNameByNum num) -> CString {
		if (bIsOrigin) return CommonUtil::GetOriginNameByNumber(nNum, num);
		else return CommonUtil::GetDiffNameByNumber(nNum, num);
		};

	lines.push_back(_T("========================================"));
	lines.push_back(_T("[Input Data 정보]"));
	lines.push_back(_T("----------------------------------------------------"));

	bool bHasData = false;
	// 랙번호, 슬롯번호, 포트번호 1부터 시작
	for (int chassis = 1; chassis <= MAX_IO_CHASSIS; ++chassis)
	{
		for (int slot = 1; slot <= MAX_IO_CARD_SLOT; ++slot)
		{
			for (int port = 1; port <= MAX_IO_CARD_PORT; ++port)
			{
				const auto& indata = inputData.InData[chassis][slot][port];
				if (indata.Kind != 0 && indata.Kind != 0xFF)
				{
					CString kindStr = _T("기타");
					GetDBNameByNum dbType = TrackIdx;

					// Kind 값에 따른 장치 종류 매핑 (프로젝트 사양에 맞게 조정 가능)
					if (indata.Kind == 'T' || indata.Kind == 1) {
						kindStr = _T("궤도"); dbType = TrackIdx;
					}
					else if (indata.Kind == 'S' || indata.Kind == 2) {
						kindStr = _T("신호기"); dbType = SignalIdx;
					}
					else if (indata.Kind == 'W' || indata.Kind == 3) {
						kindStr = _T("선로전환기"); dbType = SwitchIdx;
					}

					CString targetName = GetDBName(indata.TableIdx, dbType);

					temp.Format(_T("  - [서브랙: %d, 슬롯: %d, 포트: %d] 종류: %s, Table Index: %d (%s), Bit: %d"),
						chassis, slot, port, (LPCTSTR)kindStr, indata.TableIdx, (LPCTSTR)targetName, indata.BitNo);
					lines.push_back(temp);
					bHasData = true;
				}
			}
		}
	}

	if (!bHasData)
	{
		lines.push_back(_T("  - 등록된 Input Data가 없습니다."));
	}

	lines.push_back(_T(""));
	return lines;
}

// 2. I/O Card Address 정보 텍스트 변환
std::vector<CString> DiffCompareFrame::ConvertIoCardAddressInfoText(const IoCardAddressType& cardAddr, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;

	lines.push_back(_T("========================================"));
	lines.push_back(_T("[I/O Card Address 정보]"));
	lines.push_back(_T("--------------------------------------------------"));

	bool bHasData = false;
	// 랙번호, 슬롯번호 1부터 시작
	for (int chassis = 1; chassis <= MAX_IO_CHASSIS; ++chassis)
	{
		for (int slot = 1; slot <= MAX_IO_CARD_SLOT; ++slot)
		{
			const auto& card = cardAddr.Card[chassis][slot];
			// 빈 슬롯(Type == 0)이 아닌 경우만 출력
			if (card.Type != 0 && card.Type != 0xFFFF)
			{
				CString typeStr = _T("알 수 없음");
				if (card.Type == 1) typeStr = _T("IN (입력 카드)");
				else if (card.Type == 2) typeStr = _T("OUT (출력 카드)");
				else if (card.Type == 3 || card.Type == 4) typeStr = _T("PDO (제어 카드)");

				temp.Format(_T("  - [서브랙: %d, 슬롯: %d] 카드 타입: %s (Type: %d), 슬롯 번호: %d"),
					chassis, slot, (LPCTSTR)typeStr, card.Type, card.SlotNo);
				lines.push_back(temp);
				bHasData = true;
			}
		}
	}

	if (!bHasData)
	{
		lines.push_back(_T("  - 설정된 I/O Card가 없습니다."));
	}

	lines.push_back(_T(""));
	return lines;
}
void DiffCompareFrame::SetIncardInfo()
{
	auto& dc = DataComparison::GetInstance();

	std::vector<CString> leftLines;
	std::vector<CString> rightLines;

	const bool hasOrigin = dc.HasOriginal();
	const bool hasDiff = dc.HasDiff();

	// 1. 둘 다 데이터가 없으면 중단
	if (!hasOrigin && !hasDiff)
	{
		return;
	}

	// 2. 원본(Left) 데이터 수집 및 예외 처리
	if (hasOrigin)
	{
		auto inCardInfo = dc.GetOriginalInCardInfo();

		leftLines = ConvertInCardInfoText(inCardInfo, true);
	}
	else
	{
		leftLines.push_back(_T("선택한 파일이 없습니다."));
	}

	// 3. 비교군(Right) 데이터 수집 및 예외 처리
	if (hasDiff)
	{
		auto DiffInCardInfo = dc.GetDiffInCardInfo();
		rightLines = ConvertInCardInfoText(DiffInCardInfo, false);
	}
	else
	{
		rightLines.push_back(_T("비교할 파일이 없습니다."));
	}

	// 4. 수집된 라인을 전달하여 [Diff 정렬 -> 화면 출력 -> 색상 하이라이트] 일괄 처리
	ApplyDiffToUI(leftLines, rightLines);
}
std::vector<CString> DiffCompareFrame::ConvertInCardInfoText(const std::span<INCARDTABLE>& list, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;

	for (const auto& item : list)
	{
		// 유효하지 않은 데이터 건너뛰기
		if (item.Name[0] == 0 || (unsigned char)item.Name[0] == 0xFF) continue;

		// 1. 블록 헤더 (LCS 매칭의 고유 키)
		lines.push_back(_T("========================================"));
		CString name = GetSafeString(item.Name, 20);
		name.Trim();
		temp.Format(_T("[입력 카드 이름] %s"), (LPCTSTR)name);
		lines.push_back(temp);
		lines.push_back(_T("------------------------------------------------"));

		// 2. 랙, 슬롯, 포트 위치 정보
		temp.Format(_T("  - 위치: 랙(%d) / 슬롯(%d) / 포트(%d)"), item.RackNo, item.SlotNo, item.PortNo);
		lines.push_back(temp);

		// 3. 비트 이름 및 표찰 이름
		CString bitName = GetSafeString(item.BitName, 20);
		bitName.Trim();

		temp.Format(_T("  - 비트 이름: %s"), (LPCTSTR)bitName);
		lines.push_back(temp);

		// 4. 종류('T', 'S', 'P', 'L', 'N'), 인덱스, 비트 오프셋
		CString kindStr = _T("");
		switch (item.Kind) {
		case 'V': kindStr = _T("VRD"); break;
		case 'T': kindStr = _T("궤도"); break;
		case 'S': kindStr = _T("신호기"); break;
		case 'P': kindStr = _T("선로전환기"); break;
		case 'L': kindStr = _T("LMR"); break;
		case 'R': kindStr = _T("진로선별둥"); break;
		case 'N': kindStr = _T("역공통"); break;
		case 'B': kindStr = _T("폐색"); break;
		case 'C': kindStr = _T("건널목(고장검지)"); break;
		case 'c': kindStr = _T("건널목(제어건널목)"); break;
		case 't': kindStr = _T("타역궤도"); break;
		case 's': kindStr = _T("타역 신호기"); break;
		case 'p': kindStr = _T("타역 선로전환기"); break;
		case 'D': kindStr = _T("전차선 절연구간"); break;
		case 'J': kindStr = _T("지장물"); break;
		case 'K': kindStr = _T("출발반응등"); break;
		case 'F': kindStr = _T("기타 고장"); break;
		case 'W': kindStr = _T("소속역 정보"); break;
		case 'H': kindStr = _T("열차진입 방지"); break;
		case 'h': kindStr = _T("히터"); break;
		case 'E': kindStr = _T("연동장치"); break;
		}
		temp.Format(_T("  - 종류: %s, Table Index: %d"), (LPCTSTR)kindStr, item.Idx);
		lines.push_back(temp);

		// 항목 간 여백 추가
		lines.push_back(_T(""));
	}

	return lines;
}
void DiffCompareFrame::SetOutCardInfo()
{
	auto& dc = DataComparison::GetInstance();

	std::vector<CString> leftLines;
	std::vector<CString> rightLines;

	const bool hasOrigin = dc.HasOriginal();
	const bool hasDiff = dc.HasDiff();

	// 1. 둘 다 데이터가 없으면 중단
	if (!hasOrigin && !hasDiff)
	{
		return;
	}

	// 2. 원본(Left) 데이터 수집 및 예외 처리
	if (hasOrigin)
	{
		auto outCardInfo = dc.GetOriginalOutCardInfo();

		leftLines = ConvertOutCardInfoText(outCardInfo, true);
	}
	else
	{
		leftLines.push_back(_T("선택한 파일이 없습니다."));
	}

	// 3. 비교군(Right) 데이터 수집 및 예외 처리
	if (hasDiff)
	{
		auto DiffoutCardInfo = dc.GetDiffOutCardInfo();
		rightLines = ConvertOutCardInfoText(DiffoutCardInfo, false);
	}
	else
	{
		rightLines.push_back(_T("비교할 파일이 없습니다."));
	}

	// 4. 수집된 라인을 전달하여 [Diff 정렬 -> 화면 출력 -> 색상 하이라이트] 일괄 처리
	ApplyDiffToUI(leftLines, rightLines);
}
std::vector<CString> DiffCompareFrame::ConvertOutCardInfoText(const std::span<OUTCARDTABLE>& list, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;

	for (const auto& item : list)
	{
		// 유효하지 않은 데이터 건너뛰기
		if (item.Name[0] == 0 || (unsigned char)item.Name[0] == 0xFF) continue;

		// 1. 블록 헤더 (LCS 매칭의 고유 키)
		lines.push_back(_T("========================================"));
		CString name = GetSafeString(item.Name, 20);
		name.Trim();
		temp.Format(_T("[출력 카드 이름] %s"), (LPCTSTR)name);
		lines.push_back(temp);
		lines.push_back(_T("------------------------------------------------"));

		// 2. 랙, 슬롯, 포트 위치 정보
		temp.Format(_T("  - 위치: 랙(%d) / 슬롯(%d) / 포트(%d)"), item.RackNo, item.SlotNo, item.PortNo);
		lines.push_back(temp);

		// 3. 비트 이름 (BitName은 19바이트 규격 반영)
		CString bitName = GetSafeString(item.BitName, 19);
		bitName.Trim();
		temp.Format(_T("  - 비트 이름: %s"), (LPCTSTR)bitName);
		lines.push_back(temp);

		// 4. 종류, 테이블 인덱스, 비트 오프셋
		CString kindStr = _T("기타('N')");
		switch (item.Kind) {
		case 'V': kindStr = _T("VRD"); break;
		case 'T': kindStr = _T("궤도"); break;
		case 'S': kindStr = _T("신호기"); break;
		case 'P': kindStr = _T("선로전환기"); break;
		case 'L': kindStr = _T("LMR"); break;
		case 'R': kindStr = _T("진로선별둥"); break;
		case 'N': kindStr = _T("역공통"); break;
		case 'B': kindStr = _T("폐색"); break;
		case 'C': kindStr = _T("건널목(고장검지)"); break;
		case 'c': kindStr = _T("건널목(제어건널목)"); break;
		case 't': kindStr = _T("타역궤도"); break;
		case 's': kindStr = _T("타역 신호기"); break;
		case 'p': kindStr = _T("타역 선로전환기"); break;
		case 'D': kindStr = _T("전차선 절연구간"); break;
		case 'J': kindStr = _T("지장물"); break;
		case 'K': kindStr = _T("출발반응등"); break;
		case 'F': kindStr = _T("기타 고장"); break;
		case 'W': kindStr = _T("소속역 정보"); break;
		case 'H': kindStr = _T("열차진입 방지"); break;
		case 'h': kindStr = _T("히터"); break;
		case 'E': kindStr = _T("연동장치"); break;
		}
		temp.Format(_T("  - 종류: %s, Table Index: %d"), (LPCTSTR)kindStr, item.Idx);
		lines.push_back(temp);

		// 5. 궤도('T') 속도코드 출력 구분 처리 (주석 규격 반영)
		if (item.Kind == 'T') {
			CString speedStr = _T("");
			switch (item.BitNo) {
			case 1: speedStr = _T("25"); break;
			case 2: speedStr = _T("40"); break;
			case 3: speedStr = _T("60"); break;
			case 4: speedStr = _T("70"); break;
			case 5: speedStr = _T("80"); break;
			case 6: speedStr = _T("CAB"); break;
			case 7: speedStr = _T("YD"); break;
			case 8: speedStr = _T("YC"); break;
			}
			temp.Format(_T("  - 궤도 속도코드 구분: %s"), (LPCTSTR)speedStr);
			lines.push_back(temp);
		}
		else {
			lines.push_back(_T(""));
		}

		// 항목 간 여백 추가
		lines.push_back(_T(""));
	}

	return lines;
}

//void DiffCompareFrame::SetLogicInfo()
//{
//	auto& dc = DataComparison::GetInstance();
//	if (!dc.HasOriginal() && !dc.HasDiff()) return;
//
//	CWaitCursor wait; // 모래시계 커서 표시
//
//	//m_wndProgressBar.ShowWindow(SW_SHOW);
//	//m_wndProgressBar.SetMarquee(TRUE, 30);
//
//	// 스레드 내부에서 안전하게 쓰기 위해 필요한 데이터를 복사(Capture)합니다.
//	bool hasOrigin = dc.HasOriginal();
//	bool hasDiff = dc.HasDiff();
//	std::vector<std::shared_ptr<LOGIC_VARIABLE>> originList = hasOrigin ? dc.GetOriginalLogicVariable() : std::vector<std::shared_ptr<LOGIC_VARIABLE>>();
//	std::vector<std::shared_ptr<LOGIC_VARIABLE>> diffList = hasDiff ? dc.GetDiffLogicVariable() : std::vector<std::shared_ptr<LOGIC_VARIABLE>>();
//	HWND hWnd = this->m_hWnd;
//
//	// WThread의 작업 큐에 람다식(Task) 등록
//	m_logicThread.EnqueueTask([this, hWnd, hasOrigin, hasDiff, originList, diffList]() mutable {
//
//		std::vector<CString> leftLines;
//		std::vector<CString> rightLines;
//
//		// 1. 원본 변환 (Static 함수 또는 별도 안전 함수 호출 권장)
//		if (hasOrigin) {
//			leftLines = ConvertLogicInfoText(originList, true);
//		}
//		else {
//			leftLines.push_back(_T("선택한 파일이 없습니다."));
//		}
//
//		// 2. 비교군 변환
//		if (hasDiff) {
//			rightLines = ConvertLogicInfoText(diffList, false);
//		}
//		else {
//			rightLines.push_back(_T("비교할 파일이 없습니다."));
//		}
//
//		// 3. 무거운 2만 건 Diff 연산 수행 (백그라운드 스레드에서 처리되므로 UI 안 멈춤)
//		std::vector<DiffLine> diffResults = ComputeBinDiff(leftLines, rightLines);
//
//
//
//		ResultPackage* pPackage = new ResultPackage{
//			std::move(leftLines),
//			std::move(rightLines),
//			std::move(diffResults)
//		};
//
//		// 5. 연산 완료 메시지를 메인 UI 스레드로 안전하게 전송
//		::PostMessage(hWnd, WM_LOGIC_DIFF_FINISHED, 0, reinterpret_cast<LPARAM>(pPackage));
//		});
//}
std::vector<CString> DiffCompareFrame::ConvertLogicInfoText(const std::span<std::shared_ptr<LOGIC_VARIABLE>>& logicList, bool bIsOrigin)
{
	std::vector<CString> lines;
	CString temp;

	// 원본/비교군에 따라 CommonUtil을 통해 DB 연결 장비 이름을 가져오는 람다
	auto GetDBName = [&](UCHAR kind, UINT tableIdx) -> CString {
		GetDBNameByNum numType = GetDBNameByNum::TrackIdx;
		if (kind == 'S' || kind == 's') numType = GetDBNameByNum::SignalIdx;
		else if (kind == 'P' || kind == 'p') numType = GetDBNameByNum::SwitchIdx;
		else if (kind == 'T' || kind == 't') numType = GetDBNameByNum::TrackIdx;
		else return _T("");

		BYTE nNum = static_cast<BYTE>(tableIdx);
		if (bIsOrigin) {
			return CommonUtil::GetOriginNameByNumber(nNum, numType);
		}
		else {
			return CommonUtil::GetDiffNameByNumber(nNum, numType);
		}
		};

	for (const auto& item : logicList)
	{
		// 유효하지 않은 데이터 건너뛰기 (이름 첫 바이트가 0이거나 0xFF인 경우)
		if (item->szVarName[0] == 0 || (unsigned char)item->szVarName[0] == 0xFF) continue;

		CString varName = GetSafeString(item->szVarName, 46);
		varName.Trim();

		// 1. 블록 헤더 (BinDiff 매칭의 고유 키 역할)
		lines.push_back(_T("========================================"));
		temp.Format(_T("[로직정보] 이름:%s"), (LPCTSTR)varName);
		lines.push_back(temp);
		lines.push_back(_T("----------------------------------------"));
		temp.Format(_T("인덱스 : %d"), item->nLogicIdx);
		// 2. 로직 구분 (LogicKind) 문자 해석
		CString kindName = _T("기타");
		switch (item->LogicKind) {
		case 'V': kindName = _T("VRD 속도코드제어장치"); break;
		case 'T': kindName = _T("궤도"); break;
		case 'P': kindName = _T("선로전환기"); break;
		case 'S': kindName = _T("신호기"); break;
		case 'L': kindName = _T("LMR"); break;
		case 'R': kindName = _T("진로"); break;
		case 'N': kindName = _T("역공통"); break;
		case 'B': kindName = _T("폐색"); break;
		case 'C': kindName = _T("건널목(고장검지)"); break;
		case 'c': kindName = _T("건널목(제어)"); break;
		case 't': kindName = _T("타역 궤도"); break;
		case 's': kindName = _T("타역 신호기"); break;
		case 'p': kindName = _T("타역 선로전환기"); break;
		case 'D': kindName = _T("전차선 절연구간"); break;
		case 'J': kindName = _T("지장물"); break;
		case 'K': kindName = _T("출발반응등"); break;
		case 'F': kindName = _T("기타 고장"); break;
		case 'W': kindName = _T("소속역 정보"); break;
		case 'H': kindName = _T("CPT"); break;
		case 'h': kindName = _T("히터"); break;
		case 'E': kindName = _T("연동장치 정보"); break;
		}
		temp.Format(_T("  - 로직 구분: %c (%s)"), item->LogicKind, (LPCTSTR)kindName);
		lines.push_back(temp);

		// 3. 연동DB 매핑 정보 및 해석된 장비명
		CString dbTargetName = GetDBName(item->Kind, item->TableIdx);
		if (dbTargetName.IsEmpty()) dbTargetName = _T("-");
		temp.Format(_T("  - DB 매핑: Kind:%c, TableIdx:%d, BitNo:%d (장비명: %s)"),
			item->Kind, item->TableIdx, item->BitNo, (LPCTSTR)dbTargetName);
		lines.push_back(temp);

		// 4. 카드 정보 (CARDINFO)
		CString cardTypeStr = _T("카드 정보 없음");
		if (item->CARDINFO.CardType == 1) cardTypeStr = _T("IN");
		else if (item->CARDINFO.CardType == 2) cardTypeStr = _T("OUT");
		else if (item->CARDINFO.CardType == 3 || item->CARDINFO.CardType == 4) cardTypeStr = _T("PDO");

		temp.Format(_T("  - 카드 정보: 타입(%s), 랙(%d), 슬롯(%d), 포트(%d), attr(0x%02X), param(0x%02X)"),
			(LPCTSTR)cardTypeStr, item->CARDINFO.nRackNo, item->CARDINFO.nSlotNo,
			item->CARDINFO.nPortNo, item->CARDINFO.attr, item->CARDINFO.param);
		lines.push_back(temp);

		// 5. 로직 타입(LogicType) 및 타이머 정보
		CString logicTypeStr = _T("");
		if (item->LogicType == 1) logicTypeStr = _T("입력(I)");
		else if (item->LogicType == 2) logicTypeStr = _T("출력(O)");
		else if (item->LogicType == 4) logicTypeStr = _T("PDO(P)");
		else logicTypeStr.Format(_T("%d"), item->LogicType);

		CString timerKindStr = _T("없음/기타");
		switch (item->TimerKind) {
		case 2: timerKindStr = _T("낙하 후 Delay 여자 (2)"); break;
		case 3: timerKindStr = _T("여자 후 Delay 낙하 (3)"); break;
		case 4: timerKindStr = _T("조건 만족 시 Delay 후 ON-OFF (4)"); break;
		case 5: timerKindStr = _T("OSCI (반복) (5)"); break;
		case 6: timerKindStr = _T("TRIG (6)"); break;
		}

		temp.Format(_T("  - 동작 타입: LogicType(%s), TimerKind(%s), TimeValue:%d ms, TimeValueDB:%d ms"),
			(LPCTSTR)logicTypeStr, (LPCTSTR)timerKindStr, item->TimeValue, item->TimeValueDB);
		lines.push_back(temp);

		// 항목 간 여백 추가
		lines.push_back(_T(""));
	}

	return lines;
}


void DiffCompareFrame::SetLogicInfo(UCHAR logicKind)
{
	// 2만 건 중에서 선택한 로직 종류에 해당하는 데이터만 빠르게 필터링하여 가져옴
	auto originalList = DataComparison::GetInstance().GetOriginalLogicVariable(logicKind);
	auto diffList = DataComparison::GetInstance().GetDiffLogicVariable(logicKind);

	std::vector<CString> origLines = ConvertLogicInfoText(originalList, true);
	std::vector<CString> diffLines = ConvertLogicInfoText(diffList, false);

	ApplyDiffToUI(origLines, diffLines);
}


// ==========================================
// 연산 완료: 텍스트 주입 및 마커 청크 시작
// ==========================================
//LRESULT DiffCompareFrame::OnLogicFinished(WPARAM wParam, LPARAM lParam)
//{
//	ResultPackage* pPackage = reinterpret_cast<ResultPackage*>(lParam);
//	if (!pPackage) return 0;
//
//	CDiffGridPaneView* pLeftView = DYNAMIC_DOWNCAST(CDiffGridPaneView, m_wndSplitter.GetPane(0, 0));
//	CDiffGridRightView* pRightView = DYNAMIC_DOWNCAST(CDiffGridRightView, m_wndSplitter.GetPane(0, 1));
//
//	if (pLeftView && pRightView)
//	{
//		// 각 뷰에 텍스트 및 전체 Diff 데이터 위임
//		pLeftView->SetLogicData(pPackage->left, pPackage->diffs);
//		pRightView->SetLogicData(pPackage->right, pPackage->diffs);
//
//		// 피어 에디터 동기화 연결
//		CustomBCGPEditCtrl* pLeftEdit = &pLeftView->m_wndLeftEditLDat;
//		CustomBCGPEditCtrl* pRightEdit = &pRightView->m_wndRightEditLDat;
//		pLeftEdit->m_pPeerEdit = pRightEdit;
//		pRightEdit->m_pPeerEdit = pLeftEdit;
//	}
//
//	delete pPackage;
//	this->EnableWindow(TRUE);
//	this->SetFocus();
//
//	return 0;
//}
// ==========================================
// 3. 1,000줄씩 쪼개서 마커를 렌더링하는 핵심 함수
// ==========================================
//LRESULT DiffCompareFrame::OnRenderNextChunk(WPARAM wParam, LPARAM lParam)
//{
//	CDiffGridPaneView* pLeftView = DYNAMIC_DOWNCAST(CDiffGridPaneView, m_wndSplitter.GetPane(0, 0));
//	CDiffGridRightView* pRightView = DYNAMIC_DOWNCAST(CDiffGridRightView, m_wndSplitter.GetPane(0, 1));
//	if (!pLeftView || !pRightView) return 0;
//
//	CustomBCGPEditCtrl* pLeftEdit = &pLeftView->m_wndLeftEditLDat;
//	CustomBCGPEditCtrl* pRightEdit = &pRightView->m_wndRightEditLDat;
//
//	int totalSize = static_cast<int>(m_tempDiffResults.size());
//	if (totalSize == 0 || m_nCurrentChunkIndex >= totalSize) return 0;
//
//	int chunkSize = 1000; // 한 번에 처리할 묶음 크기 (1,000줄씩)
//
//	// ★ 이번에 처리할 정방향 구간 계산 (예: 0 ~ 999, 그 다음은 1000 ~ 1999)
//	int startIndex = m_nCurrentChunkIndex;
//	int endIndex = min(startIndex + chunkSize, totalSize);
//
//	pLeftEdit->SetRedraw(FALSE);
//	pRightEdit->SetRedraw(FALSE);
//
//	COLORREF dwDefText = RGB(0, 0, 0);
//	COLORREF clrChange = RGB(255, 230, 150);
//	COLORREF clrDelete = RGB(255, 180, 180);
//	COLORREF clrInsert = RGB(180, 255, 180);
//	COLORREF clrEmpty = RGB(240, 240, 240);
//
//	// ★ 딱 이번 청크 범위(startIndex ~ endIndex)만 정방향으로 순회
//	for (int row = startIndex; row < endIndex; ++row)
//	{
//		switch (m_tempDiffResults[row].type)
//		{
//		case DIFF_CHANGE:
//			pLeftEdit->SetLineColorMarker(row, dwDefText, clrChange, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
//			pRightEdit->SetLineColorMarker(row, dwDefText, clrChange, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
//			break;
//		case DIFF_DELETE:
//			pLeftEdit->SetLineColorMarker(row, dwDefText, clrDelete, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
//			pRightEdit->SetLineColorMarker(row, dwDefText, clrEmpty, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
//			break;
//		case DIFF_INSERT:
//			pLeftEdit->SetLineColorMarker(row, dwDefText, clrEmpty, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
//			pRightEdit->SetLineColorMarker(row, dwDefText, clrInsert, TRUE, 0, g_dwBCGPEdit_LineColorMarker, 0, NULL, FALSE);
//			break;
//		default:
//			break;
//		}
//	}
//
//	pLeftEdit->SetRedraw(TRUE);
//	pRightEdit->SetRedraw(TRUE);
//	pLeftEdit->RedrawWindow(NULL, NULL, RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE);
//	pRightEdit->RedrawWindow(NULL, NULL, RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE);
//
//	// 다음 청크 시작점으로 인덱스 이동
//	m_nCurrentChunkIndex = endIndex;
//
//	// (선택) 프로그레스 다이얼로그 퍼센트 연동 시
//	// int percent = (m_nCurrentChunkIndex * 100) / totalSize;
//	// m_progressDlg.SetPos(percent);
//
//	// 아직 처리할 데이터가 남았다면 다음 메시지 예약
//	if (m_nCurrentChunkIndex < totalSize)
//	{
//		::PostMessage(m_hWnd, WM_RENDER_NEXT_CHUNK, 0, 0);
//	}
//	else
//	{
//		// [모든 렌더링 완료!]
//		pLeftEdit->m_pPeerEdit = pRightEdit;
//		pRightEdit->m_pPeerEdit = pLeftEdit;
//
//		// m_progressDlg.DestroyWindow();
//		this->EnableWindow(TRUE);
//		this->SetFocus();
//	}
//
//	return 0;
//}

